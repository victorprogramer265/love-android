-- audio.lua
local Audio = {}

Audio.volumenMusica = 1.0
Audio.volumenFX = 1.0

Audio.efectoClick = nil
Audio.listaMusica = {}
Audio.musicaActual = nil
Audio.indiceCancionActual = -1

-- Fuente de audio exclusiva para el Rey Bicho
Audio.musicaRey = nil

function Audio.cargar()
    if love.filesystem.getInfo("assets/FXS/click.mp3") then
        Audio.efectoClick = love.audio.newSource("assets/FXS/click.mp3", "static")
    end

    -- Cargar canción específica del Rey Bicho
    if love.filesystem.getInfo("assets/MUSIC/primary containment.mp3") then
        Audio.musicaRey = love.audio.newSource("assets/MUSIC/primary containment.mp3", "stream")
        Audio.musicaRey:setLooping(true)
    end

    Audio.listaMusica = {}
    if love.filesystem.getInfo("assets/MUSIC") then
        local archivos = love.filesystem.getDirectoryItems("assets/MUSIC")
        for _, archivo in ipairs(archivos) do
            -- Excluimos la del rey del ciclo aleatorio general si está en la misma carpeta
            if archivo ~= "primary containment.mp3" and (archivo:match("%.mp3$") or archivo:match("%.ogg$") or archivo:match("%.wav$")) then
                table.insert(Audio.listaMusica, "assets/MUSIC/" .. archivo)
            end
        end
    end

    Audio.reproducirSiguienteMusica()
end

function Audio.reproducirClick()
    if Audio.efectoClick and Audio.volumenFX > 0 then
        Audio.efectoClick:setVolume(Audio.volumenFX)
        Audio.efectoClick:stop()
        Audio.efectoClick:play()
    end
end

function Audio.reproducirSiguienteMusica()
    -- Si la música del rey está sonando, no interferimos con la aleatoria
    if Audio.musicaRey and Audio.musicaRey:isPlaying() then return end

    if #Audio.listaMusica == 0 then return end

    local siguienteIndice = math.random(1, #Audio.listaMusica)
    if #Audio.listaMusica > 1 and siguienteIndice == Audio.indiceCancionActual then
        siguienteIndice = (siguienteIndice % #Audio.listaMusica) + 1
    end

    Audio.indiceCancionActual = siguienteIndice

    if Audio.musicaActual then
        Audio.musicaActual:stop()
    end

    Audio.musicaActual = love.audio.newSource(Audio.listaMusica[siguienteIndice], "stream")
    Audio.musicaActual:setVolume(Audio.volumenMusica)
    Audio.musicaActual:play()
end

function Audio.reproducirMusicaRey()
    if Audio.musicaActual then
        Audio.musicaActual:pause()
    end
    if Audio.musicaRey then
        Audio.musicaRey:setVolume(Audio.volumenMusica)
        Audio.musicaRey:play()
    end
end

function Audio.detenerMusicaRey()
    if Audio.musicaRey then
        Audio.musicaRey:stop()
    end
    if Audio.musicaActual then
        Audio.musicaActual:play()
    end
end

function Audio.update(dt)
    -- Si la música del rey no está sonando, comprobamos la normal
    if Audio.musicaRey and Audio.musicaRey:isPlaying() then return end

    if Audio.musicaActual and not Audio.musicaActual:isPlaying() then
        Audio.reproducirSiguienteMusica()
    end
end

function Audio.actualizarVolumenMusica(nuevoVolumen)
    Audio.volumenMusica = math.max(0, math.min(1, nuevoVolumen))
    if Audio.musicaActual then
        Audio.musicaActual:setVolume(Audio.volumenMusica)
    end
    if Audio.musicaRey then
        Audio.musicaRey:setVolume(Audio.volumenMusica)
    end
end

function Audio.actualizarVolumenFX(nuevoVolumen)
    Audio.volumenFX = math.max(0, math.min(1, nuevoVolumen))
end

return Audio
