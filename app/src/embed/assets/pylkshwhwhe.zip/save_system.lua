-- save_system.lua
local json = require("lib.json") -- Asegúrate de que la ruta coincida con tu librería JSON

local SaveSystem = {}
local NOMBRE_ARCHIVO = "SAV5.JSON"

-- Guardar la tabla de datos como string JSON en el disco
function SaveSystem.guardar(datos)
    local ok, contenido = pcall(json.encode, datos)
    if not ok then
        print("ERROR AL CODIFICAR JSON: " .. tostring(contenido))
        return false
    end

    local exito, mensaje = love.filesystem.write(NOMBRE_ARCHIVO, contenido)
    if not exito then
        print("ERROR AL GUARDAR ARCHIVO JSON: " .. tostring(mensaje))
        return false
    end

    return true
end

-- Cargar y decodificar el archivo JSON desde el almacenamiento de LÖVE2D
function SaveSystem.cargar()
    if love.filesystem.getInfo and love.filesystem.getInfo(NOMBRE_ARCHIVO) then
        local contenido, bytes = love.filesystem.read(NOMBRE_ARCHIVO)
        if contenido then
            local ok, resultado = pcall(json.decode, contenido)
            if ok and type(resultado) == "table" then
                return resultado
            else
                print("ERROR AL DECODIFICAR JSON: ARCHIVO CORRUPTO O FORMATO INVÁLIDO")
            end
        end
    end
    
    -- Si el archivo no existe o falla al leerse, devuelve una tabla vacía
    return {}
end

return SaveSystem
