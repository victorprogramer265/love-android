-- lib/json.lua
-- A lightweight JSON library for Lua
-- Copyright (c) 2020 rxi

local json = { _version = "2" }

local encode

local escape_char_map = {
  [ "\\" ] = "\\\\",
  [ "\"" ] = "\\\"",
  [ "\b" ] = "\\b",
  [ "\f" ] = "\\f",
  [ "\n" ] = "\\n",
  [ "\r" ] = "\\r",
  [ "\t" ] = "\\t",
}

local escape_char_map_inv = { [ "\\/" ] = "/" }
for k, v in pairs(escape_char_map) do
  escape_char_map_inv[v] = k
end

local function escape_char(c)
  return escape_char_map[c] or string.format("\\u%04x", c:byte())
end

local function encode_nil(val)
  return "null"
end

local function encode_table(val, stack)
  local res = {}
  stack = stack or {}

  if stack[val] then error("circular ref") end
  stack[val] = true

  if rawget(val, 1) ~= nil or next(val) == nil then
    local n = #val
    for i = 1, n do
      table.insert(res, encode(val[i], stack))
    end
    stack[val] = nil
    return "[" .. table.concat(res, ",") .. "]"
  else
    for k, v in pairs(val) do
      if type(k) ~= "string" then
        error("invalid table: mixed or non-string keys")
      end
      table.insert(res, encode(k, stack) .. ":" .. encode(v, stack))
    end
    stack[val] = nil
    return "{" .. table.concat(res, ",") .. "}"
  end
end

local function encode_string(val)
  return '"' .. val:gsub('[%z\1-\31\\"]', escape_char) .. '"'
end

local function encode_number(val)
  if val ~= val or val == math.huge or val == -math.huge then
    error("unexpected number value '" .. tostring(val) .. "'")
  end
  return string.format("%.14g", val)
end

local type_func_map = {
  [ "nil"     ] = encode_nil,
  [ "table"   ] = encode_table,
  [ "string"  ] = encode_string,
  [ "number"  ] = encode_number,
  [ "boolean" ] = tostring,
}

encode = function(val, stack)
  local t = type(val)
  local f = type_func_map[t]
  if f then
    return f(val, stack)
  end
  error("unexpected type '" .. t .. "'")
end

function json.encode(val)
  return encode(val)
end

local parse

local function create_whitespace_set()
  local res = {}
  for _, ch in ipairs({ " ", "\t", "\r", "\n" }) do
    res[ch] = true
  end
  return res
end

local whitespace_set = create_whitespace_set()

local function skip_whitespace(str, pos)
  while whitespace_set[str:sub(pos, pos)] do
    pos = pos + 1
  end
  return pos
end

local function parse_string(str, i)
  local res = ""
  local j = i + 1
  local k = j

  while j <= #str do
    local c = str:sub(j, j)
    if c == '"' then
      return res .. str:sub(k, j - 1), j + 1
    elseif c == "\\" then
      res = res .. str:sub(k, j - 1)
      local esc = str:sub(j + 1, j + 1)
      if esc == "u" then
        local hex = str:sub(j + 2, j + 5)
        if not hex:find("%x%x%x%x") then
          error("invalid unicode escape")
        end
        res = res .. string.char(tonumber(hex, 16))
        j = j + 6
      else
        res = res .. (escape_char_map_inv["\\" .. esc] or esc)
        j = j + 2
      end
      k = j
    else
      j = j + 1
    end
  end
  error("unterminated string")
end

local function parse_number(str, i)
  local x = str:find("[^%d%.%+%-%e%E]", i) or (#str + 1)
  local val = tonumber(str:sub(i, x - 1))
  if not val then
    error("invalid number")
  end
  return val, x
end

local function parse_literal(str, i)
  local literals = { ["true"] = true, ["false"] = false, ["null"] = nil }
  for k, v in pairs(literals) do
    if str:sub(i, i + #k - 1) == k then
      return v, i + #k
    end
  end
  error("invalid literal")
end

local function parse_array(str, i)
  local res = {}
  local n = 1
  i = i + 1
  while i <= #str do
    i = skip_whitespace(str, i)
    if str:sub(i, i) == "]" then
      return res, i + 1
    end
    local val
    val, i = parse(str, i)
    res[n] = val
    n = n + 1
    i = skip_whitespace(str, i)
    local chr = str:sub(i, i)
    if chr == "]" then
      return res, i + 1
    elseif chr == "," then
      i = i + 1
    else
      error("expected ',' or ']'")
    end
  end
  error("unterminated array")
end

local function parse_object(str, i)
  local res = {}
  i = i + 1
  while i <= #str do
    i = skip_whitespace(str, i)
    if str:sub(i, i) == "}" then
      return res, i + 1
    end
    if str:sub(i, i) ~= '"' then
      error("expected string key")
    end
    local key
    key, i = parse_string(str, i)
    i = skip_whitespace(str, i)
    if str:sub(i, i) ~= ":" then
      error("expected ':'")
    end
    i = skip_whitespace(str, i + 1)
    local val
    val, i = parse(str, i)
    res[key] = val
    i = skip_whitespace(str, i)
    local chr = str:sub(i, i)
    if chr == "}" then
      return res, i + 1
    elseif chr == "," then
      i = i + 1
    else
      error("expected ',' or '}'")
    end
  end
  error("unterminated object")
end

parse = function(str, i)
  i = skip_whitespace(str, i)
  local chr = str:sub(i, i)
  if chr == "{" then
    return parse_object(str, i)
  elseif chr == "[" then
    return parse_array(str, i)
  elseif chr == '"' then
    return parse_string(str, i)
  elseif chr:find("[%d%-]") then
    return parse_number(str, i)
  elseif chr:find("[tfn]") then
    return parse_literal(str, i)
  end
  error("unexpected character '" .. chr .. "'")
end

function json.decode(str)
  if type(str) ~= "string" then
    error("expected string")
  end
  local val, pos = parse(str, 1)
  return val
end

return json
