local Fuente = {}

Fuente.imgLetras = nil
Fuente.imgNumeros = nil
Fuente.imgSimbolos = nil

Fuente.quads = {}
Fuente.anchos = {}

-- Mapa dagiti letra (4 a fila x 7 a columna)
local MAPA_LETRAS = {
    ["A"] = {f = 1, c = 1}, ["B"] = {f = 1, c = 2}, ["C"] = {f = 1, c = 3}, ["D"] = {f = 1, c = 4},
    ["E"] = {f = 1, c = 5}, ["F"] = {f = 1, c = 6}, ["G"] = {f = 1, c = 7},
    ["H"] = {f = 2, c = 1}, ["I"] = {f = 2, c = 2}, ["J"] = {f = 2, c = 3}, ["K"] = {f = 2, c = 4},
    ["L"] = {f = 2, c = 5}, ["M"] = {f = 2, c = 6}, ["N"] = {f = 2, c = 7},
    ["O"] = {f = 3, c = 1}, ["P"] = {f = 3, c = 2}, ["Q"] = {f = 3, c = 3}, ["R"] = {f = 3, c = 4},
    ["S"] = {f = 3, c = 5}, ["T"] = {f = 3, c = 6}, ["U"] = {f = 3, c = 7},
    ["V"] = {f = 4, c = 1}, ["W"] = {f = 4, c = 2}, ["X"] = {f = 4, c = 3}, ["Y"] = {f = 4, c = 4},
    ["Z"] = {f = 4, c = 5},
    [" "] = {f = 4, c = 6}
}

-- Mapa dagiti numero (1 a fila x 10 a columna: 0 aginggana 9)
local MAPA_NUMEROS = {
    ["0"] = {f = 1, c = 1}, ["1"] = {f = 1, c = 2}, ["2"] = {f = 1, c = 3}, ["3"] = {f = 1, c = 4}, ["4"] = {f = 1, c = 5},
    ["5"] = {f = 1, c = 6}, ["6"] = {f = 1, c = 7}, ["7"] = {f = 1, c = 8}, ["8"] = {f = 1, c = 9}, ["9"] = {f = 1, c = 10}
}

-- Mapa dagiti simbolo (3 a fila x 6 a columna)
local MAPA_SIMBOLOS = {
    -- Fila 1
    ["$"] = {f = 1, c = 1}, ["#"] = {f = 1, c = 2}, ["-"] = {f = 1, c = 3},
    ["+"] = {f = 1, c = 4}, ["/"] = {f = 1, c = 5}, ["%"] = {f = 1, c = 6},
    
    -- Fila 2
    ["?"] = {f = 2, c = 1}, ["¿"] = {f = 2, c = 2}, ["@"] = {f = 2, c = 3},
    [","] = {f = 2, c = 4}, ["'"] = {f = 2, c = 5}, [":"] = {f = 2, c = 6},
    
    -- Fila 3
    [";"] = {f = 3, c = 1}, ["="] = {f = 3, c = 2}
}

function Fuente.cargar()
    -- Cargar letras.png (Grid: 7 columnas, 4 filas)
    if love.filesystem.getInfo("assets/letras.png") then
        Fuente.imgLetras = love.graphics.newImage("assets/letras.png")
        Fuente.imgLetras:setFilter("nearest", "nearest")
        local w = Fuente.imgLetras:getWidth()
        local h = Fuente.imgLetras:getHeight()
        local anchoCol = w / 7
        local altoFila = h / 4
        for char, info in pairs(MAPA_LETRAS) do
            local padding = 2
            local x = ((info.c - 1) * anchoCol) + padding
            local y = ((info.f - 1) * altoFila) + padding
            local aReal = anchoCol - (padding * 2)
            local hReal = altoFila - (padding * 2)
            Fuente.quads[char] = {quad = love.graphics.newQuad(x, y, aReal, hReal, w, h), img = Fuente.imgLetras}
            Fuente.anchos[char] = aReal
        end
    end

    -- Cargar numeros.png (Grid: 10 columnas, 1 fila)
    if love.filesystem.getInfo("assets/numeros.png") then
        Fuente.imgNumeros = love.graphics.newImage("assets/numeros.png")
        Fuente.imgNumeros:setFilter("nearest", "nearest")
        local w = Fuente.imgNumeros:getWidth()
        local h = Fuente.imgNumeros:getHeight()
        local anchoCol = w / 10
        local altoFila = h / 1
        for char, info in pairs(MAPA_NUMEROS) do
            local padding = 2
            local x = ((info.c - 1) * anchoCol) + padding
            local y = ((info.f - 1) * altoFila) + padding
            local aReal = anchoCol - (padding * 2)
            local hReal = altoFila - (padding * 2)
            Fuente.quads[char] = {quad = love.graphics.newQuad(x, y, aReal, hReal, w, h), img = Fuente.imgNumeros}
            Fuente.anchos[char] = aReal
        end
    end

    -- Cargar simbolos.png (Grid: 6 columnas, 3 filas)
    if love.filesystem.getInfo("assets/simbolos.png") then
        Fuente.imgSimbolos = love.graphics.newImage("assets/simbolos.png")
        Fuente.imgSimbolos:setFilter("nearest", "nearest")
        local w = Fuente.imgSimbolos:getWidth()
        local h = Fuente.imgSimbolos:getHeight()
        local anchoCol = w / 6
        local altoFila = h / 3
        for char, info in pairs(MAPA_SIMBOLOS) do
            local padding = 2
            local x = ((info.c - 1) * anchoCol) + padding
            local y = ((info.f - 1) * altoFila) + padding
            local aReal = anchoCol - (padding * 2)
            local hReal = altoFila - (padding * 2)
            Fuente.quads[char] = {quad = love.graphics.newQuad(x, y, aReal, hReal, w, h), img = Fuente.imgSimbolos}
            Fuente.anchos[char] = aReal
        end
    end
end

function Fuente.obtenerAncho(texto, escala)
    escala = ((escala or 0.13) * 1.1)
    local ancho = 0
    texto = tostring(texto):upper()
    for i = 1, #texto do
        local char = texto:sub(i, i)
        if Fuente.anchos[char] then
            ancho = ancho + (Fuente.anchos[char] * escala)
        end
    end
    return ancho
end

function Fuente.dibujar(texto, x, y, escala)
    escala = ((escala or 0.13) * 1.1)
    
    local cursorX = x
    local cursorY = y
    texto = tostring(texto):upper()

    for i = 1, #texto do
        local char = texto:sub(i, i)

        if Fuente.quads[char] then
            if char ~= " " then
                love.graphics.setColor(1, 1, 1)
                love.graphics.draw(Fuente.quads[char].img, Fuente.quads[char].quad, math.floor(cursorX), math.floor(cursorY), 0, escala, escala)
            end
            
            cursorX = cursorX + (Fuente.anchos[char] * escala)
        end
    end
end

return Fuente
