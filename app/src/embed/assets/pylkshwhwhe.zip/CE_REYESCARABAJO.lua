-- CE_REYESCARABAJO.lua
local CE_REYESCARABAJO = {}

CE_REYESCARABAJO.listaCodigos = {
    {
        codigo = "REYESCARABAJO",
        recompensaMonedas = 5000,
        pistaES = "El nombre de nuestro gran monarca insecto.",
        pistaEN = "The name of our great insect monarch."
    },
    {
        codigo = "BIENVESTIR",
        recompensaMonedas = 2000,
        pistaES = "Lo que distingue a las criaturas elegantes de este reino.",
        pistaEN = "What distinguishes the elegant creatures of this realm."
    },
    {
        codigo = "MUTANTEPRO2",
        recompensaPersonajeId = 2, -- Otorga el Escarabajo Tóxico (ID 2)
        pistaES = "Un codigo secreto para conseguir un escarabajo radioactivo gratis.",
        pistaEN = "A secret code to get a radioactive beetle for free."
    },
    {
        codigo = "CORONA2026",
        recompensaMonedas = 10000,
        pistaES = "El objeto mas valioso sobre la cabeza del rey junto con el ano actual.",
        pistaEN = "The most valuable object on the king's head along with the current year."
    },
    {
        codigo = "BACTERIABIO",
        recompensaPersonajeId = 5, -- Otorga el Escarabajo Tóxico (ID 2)
        pistaES = "Es una criatura agregada en la 1.1 con tentaculos",
        pistaEN = "It is a creature with tentacles that was added in 1.1."
    },
    
}

function CE_REYESCARABAJO.obtenerPistaAleatoria(idioma)
    if #CE_REYESCARABAJO.listaCodigos == 0 then
        return "..."
    end

    local indice = math.random(1, #CE_REYESCARABAJO.listaCodigos)
    local item = CE_REYESCARABAJO.listaCodigos[indice]

    if idioma == "en" then
        return item.pistaEN
    else
        return item.pistaES
    end
end

function CE_REYESCARABAJO.validarCodigo(codigoIngresado, idioma, datosUsuario, Personajes)
    codigoIngresado = tostring(codigoIngresado or ""):gsub("%s+", ""):upper()

    if codigoIngresado == "" then
        local pistaRandom = CE_REYESCARABAJO.obtenerPistaAleatoria(idioma)
        local msj = (idioma == "en") 
            and ("Type a code! Hint: " .. pistaRandom) 
            or ("Escribe un codigo! Pista: " .. pistaRandom)
        return false, msj
    end

    for _, item in ipairs(CE_REYESCARABAJO.listaCodigos) do
        if item.codigo == codigoIngresado then
            datosUsuario.codigosReclamados = datosUsuario.codigosReclamados or {}

            if datosUsuario.codigosReclamados[item.codigo] then
                local msj = (idioma == "en")
                    and "You have already claimed this code!"
                    or "Ya has reclamado este codigo!"
                return false, msj
            end

            datosUsuario.codigosReclamados[item.codigo] = true
            local descripcionRecompensa = ""

            if item.recompensaMonedas and item.recompensaMonedas > 0 then
                datosUsuario.monedas = (datosUsuario.monedas or 0) + item.recompensaMonedas
                descripcionRecompensa = tostring(item.recompensaMonedas) .. ((idioma == "en") and " coins!" or " monedas!")
            end

            if item.recompensaPersonajeId and Personajes then
                -- Crea la criatura asignándole posición mochila
                Personajes.crearInstancia(item.recompensaPersonajeId, 0, 0, "mochila")
                local nombrePers = Personajes.lista[item.recompensaPersonajeId] and Personajes.lista[item.recompensaPersonajeId].nombre or "Criatura"
                descripcionRecompensa = ((idioma == "en") and "Character: " or "Personaje: ") .. nombrePers
            end

            local msj = (idioma == "en")
                and ("Code claimed! You got " .. descripcionRecompensa)
                or ("Codigo reclamado! Obtuviste " .. descripcionRecompensa)
            return true, msj
        end
    end

    local pistaRandom = CE_REYESCARABAJO.obtenerPistaAleatoria(idioma)
    local msj = (idioma == "en")
        and ("Invalid code! Hint: " .. pistaRandom)
        or ("Codigo invalido! Pista: " .. pistaRandom)

    return false, msj
end

return CE_REYESCARABAJO
