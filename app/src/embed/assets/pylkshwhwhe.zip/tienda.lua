local Tienda = {}

Tienda.boton = { x = 225, y = 20, ancho = 50, alto = 50, presionado = false }
Tienda.imgBotonTienda = nil

function Tienda.cargarAssets()
    if love.filesystem.getInfo("assets/tienda.png") then
        Tienda.imgBotonTienda = love.graphics.newImage("assets/tienda.png")
        Tienda.imgBotonTienda:setFilter("nearest", "nearest")
    end
end

function Tienda.dibujarBotonHUD(UI, Fuente)
    local btn = Tienda.boton

    if btn.presionado then 
        love.graphics.setColor(0.12, 0.16, 0.24)
    else 
        love.graphics.setColor(0.18, 0.22, 0.35) 
    end
    love.graphics.rectangle("fill", btn.x, btn.y, btn.ancho, btn.alto, 8, 8)
    
    love.graphics.setColor(0.9, 0.7, 0.2)
    love.graphics.setLineWidth(2)
    love.graphics.rectangle("line", btn.x, btn.y, btn.ancho, btn.alto, 8, 8)

    if Tienda.imgBotonTienda then
        love.graphics.setColor(1, 1, 1)
        local escX = (btn.ancho - 10) / Tienda.imgBotonTienda:getWidth()
        local escY = (btn.alto - 10) / Tienda.imgBotonTienda:getHeight()
        love.graphics.draw(Tienda.imgBotonTienda, btn.x + 5, btn.y + 5, 0, escX, escY)
    end

    love.graphics.setColor(1, 1, 1)
    local textoTienda = string.upper(UI.getTexto("tienda"))
    local escalaTexto = 0.05
    local anchoTextoTienda = Fuente.obtenerAncho(textoTienda, escalaTexto)
    local posXTexto = btn.x + (btn.ancho / 2) - (anchoTextoTienda / 2)
    local posYTexto = btn.y + btn.alto + 4
    Fuente.dibujar(textoTienda, posXTexto, posYTexto, escalaTexto)
end

return Tienda
