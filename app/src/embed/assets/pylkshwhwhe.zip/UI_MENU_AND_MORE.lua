-- ============================================================================
-- [PUNTO 1: CONFIGURACIÓN INICIAL Y DICCIONARIO DE IDIOMAS (ES/EN)]
-- ============================================================================
local UI = {}

UI.VIRTUAL_ANCHO = 360
UI.VIRTUAL_ALTO = 640
UI.estadoJuego = "menu"
UI.mundoActual = 1

UI.idioma = "es"

UI.textos = {
    es = {
        jugar = "JUGAR",
        mundo2 = "MUNDO 2",
        mundo1 = "MUNDO 1",
        menu = "MENU",
        monedas = "MONEDAS ",
        configuracion = "CONFIGURACION",
        musica = "MUSICA",
        efectos = "EFECTOS FX",
        modoOscuro = "MODO OSCURO",
        saltarAnimaciones = "SALTAR ANIMACIONES",
        mostrarDatos = "MOSTRAR DATOS",
        mostrarLogos = "PANTALLA LOGOS",
        idioma = "IDIOMA",
        tienda = "TIENDA",
        comprar = "COMPRAR",
        colocar = "COLOCAR",
        mochila = "MOCHILA",
        mochilaVacia = "MOCHILA VACIA",
        nivel = "NIVEL",
        mps = "MPS",
        costo = "CC",
        detalles = "DETALLES",
        panelTitulo = "SECCION ESPECIAL",
        ingresarTexto = "Escribe aqui...",
        accionBoton = "ENVIAR",
        reyBichoRechazo1 = "Grrr Grrr no puedes pasar a mi reino serian 10,000 monedas",
        reyBichoRechazo2 = "Grrr Grrr No puedes pasar este es un reino de criaturas de bien vestir consigue 10,000 monedas y seras el elegido",
        mundo2Rechazo = "Necesitas 20,000 monedas para desbloquear y entrar al Mundo 2.",
        mundo2Confirmacion = "¿Deseas ir al Mundo 2?",
        mundo1Confirmacion = "¿Deseas regresar al Mundo 1?"
    },
    en = {
        jugar = "PLAY",
        mundo2 = "WORLD 2",
        mundo1 = "WORLD 1",
        menu = "MENU",
        monedas = "COINS ",
        configuracion = "SETTINGS",
        musica = "MUSIC",
        efectos = "SOUND FX",
        modoOscuro = "DARK MODE",
        saltarAnimaciones = "SKIP ANIMATIONS",
        mostrarDatos = "SHOW STATS",
        mostrarLogos = "SHOW LOGOS",
        idioma = "LANGUAGE",
        tienda = "SHOP",
        comprar = "BUY",
        colocar = "PLACE",
        mochila = "BACKPACK",
        mochilaVacia = "EMPTY BACKPACK",
        nivel = "LEVEL",
        mps = "MPS",
        costo = "COST",
        detalles = "DETAILS",
        panelTitulo = "SPECIAL SECTION",
        ingresarTexto = "Type here...",
        accionBoton = "SUBMIT",
        reyBichoRechazo1 = "Grrr Grrr you cannot enter my realm it would cost 10,000 coins",
        reyBichoRechazo2 = "Grrr Grrr You cannot enter this is a realm of well-dressed creatures get 10,000 coins and you shall be chosen",
        mundo2Rechazo = "You need 20,000 coins to unlock and enter World 2.",
        mundo2Confirmacion = "Do you want to go to world 2?",
        mundo1Confirmacion = "Do you want to go back to world 1?"
    }
}

function UI.getTexto(clave)
    local lang = UI.textos[UI.idioma] or UI.textos["es"]
    return lang[clave] or clave
end


-- ============================================================================
-- [PUNTO 2: PREFERENCIAS DE TEMA Y COLORES GLOBALES]
-- ============================================================================
UI.modoOscuro = false
UI.saltarAnimaciones = false 
UI.mostrarDatosEncima = true
UI.mostrarLogos = true 
UI.colorClaro = {0.94, 0.90, 0.55}
UI.colorOscuro = {0.22, 0.16, 0.12}


-- ============================================================================
-- [PUNTO 3: DECLARACIÓN DE ASSETS GRÁFICOS Y LOGOS DINÁMICOS]
-- ============================================================================
UI.imagenTitulo = nil
UI.imagenTituloMundo2ES = nil
UI.imagenTituloMundo2EN = nil

UI.imgBotones = nil
UI.quadBotonNormal = nil
UI.quadBotonPresionado = nil

UI.imgBotonConfigES = nil
UI.imgBotonConfigEN = nil
UI.quadConfigNormalES = nil
UI.quadConfigPresionadoES = nil
UI.quadConfigNormalEN = nil
UI.quadConfigPresionadoEN = nil

UI.imgMesa = nil
UI.imgReyBicho = nil
UI.quadReyBichoNormal = nil
UI.quadReyBichoPresionado = nil


-- ============================================================================
-- [PUNTO 4: CONFIGURACIÓN DE SLOTS INDEPENDIENTES PARA MUNDO 1 Y MUNDO 2]
-- ============================================================================
UI.mesa = { x = 20, y = 260, ancho = 320, alto = 160 }
UI.slotsMundo1 = {}
UI.slotsMundo2 = {}

local numSlots1 = 5
local tamSlot1 = 42
local sep1 = 14
local anchoTotal1 = (numSlots1 * tamSlot1) + ((numSlots1 - 1) * sep1)
local inicioX1 = UI.mesa.x + ((UI.mesa.ancho - anchoTotal1) / 2)
local slotY = UI.mesa.y - 12

for i = 1, numSlots1 do
    table.insert(UI.slotsMundo1, {
        id = i,
        x = inicioX1 + (i - 1) * (tamSlot1 + sep1),
        y = slotY,
        ancho = tamSlot1,
        alto = tamSlot1,
        contenido = nil
    })
end

-- Mundo 2 con sus propios 5 espacios independientes
for i = 1, numSlots1 do
    table.insert(UI.slotsMundo2, {
        id = i,
        x = inicioX1 + (i - 1) * (tamSlot1 + sep1),
        y = slotY,
        ancho = tamSlot1,
        alto = tamSlot1,
        contenido = nil
    })
end

UI.slots = UI.slotsMundo1

function UI.cambiarMundo(idMundo)
    UI.mundoActual = idMundo
    if idMundo == 2 then
        UI.slots = UI.slotsMundo2
    else
        UI.slots = UI.slotsMundo1
    end
end


-- ============================================================================
-- [PUNTO 5: POSICIONAMIENTO DE BOTONES Y DIÁLOGOS]
-- ============================================================================
UI.botonJugar = { x = (UI.VIRTUAL_ANCHO / 2) - 90, y = 280, ancho = 180, alto = 50, presionado = false }
UI.botonMundo2 = { x = (UI.VIRTUAL_ANCHO / 2) - 90, y = 345, ancho = 180, alto = 50, presionado = false }

UI.botonVolverMenu = { x = 15, y = 15, ancho = 100, alto = 45, presionado = false }
UI.botonConfig = { x = 15, y = 15, ancho = 50, alto = 50, presionado = false }
UI.botonReyBicho = { x = UI.VIRTUAL_ANCHO - 60, y = 15, ancho = 45, alto = 45, presionado = false }

UI.mostrarDialogoConfirmarMundo = false
UI.botonSiMundo = { x = 60, y = 390, ancho = 100, alto = 40, presionado = false }
UI.botonNoMundo = { x = 200, y = 390, ancho = 100, alto = 40, presionado = false }

UI.mostrarPanelReyBicho = false
UI.panelReyBicho = { x = 30, y = 80, ancho = 300, alto = 480 }
UI.cajaTextoReyBicho = { x = 50, y = 330, ancho = 260, alto = 35, texto = "", enfocado = false }
UI.botonAccionReyBicho = { x = 80, y = 380, ancho = 200, alto = 45, presionado = false }
UI.botonCerrarPanelReyBicho = { x = 290, y = 90, ancho = 30, alto = 30, presionado = false }

UI.mostrarDialogoReyBicho = false
UI.intentosAccesoReyBicho = 0
UI.claveDialogoActual = nil
UI.mensajeDialogoActual = nil
UI.botonCerrarDialogoReyBicho = { x = 130, y = 430, ancho = 100, alto = 35, presionado = false }

UI.mostrarDialogoMundo2 = false
UI.botonCerrarDialogoMundo2 = { x = 130, y = 430, ancho = 100, alto = 35, presionado = false }


-- ============================================================================
-- [PUNTO 6: CONFIGURACIÓN DE SLIDERS Y SWITCHES]
-- ============================================================================
UI.sliderMusica = { x = 60, y = 125, ancho = 240, alto = 16, arrastrando = false }
UI.sliderFX     = { x = 60, y = 185, ancho = 240, alto = 16, arrastrando = false }

UI.switchModoOscuro        = { x = (UI.VIRTUAL_ANCHO / 2) - 35, y = 245, ancho = 70, alto = 24 }
UI.switchSaltarAnimaciones = { x = (UI.VIRTUAL_ANCHO / 2) - 35, y = 305, ancho = 70, alto = 24 } 
UI.switchMostrarDatos      = { x = (UI.VIRTUAL_ANCHO / 2) - 35, y = 365, ancho = 70, alto = 24 }
UI.switchMostrarLogos      = { x = (UI.VIRTUAL_ANCHO / 2) - 35, y = 425, ancho = 70, alto = 24 }

UI.botonLangES = { x = (UI.VIRTUAL_ANCHO / 2) - 85, y = 490, ancho = 75, alto = 34, presionado = false }
UI.botonLangEN = { x = (UI.VIRTUAL_ANCHO / 2) + 10, y = 490, ancho = 75, alto = 34, presionado = false }


-- ============================================================================
-- [PUNTO 7: CARGA DE ASSETS GRÁFICOS]
-- ============================================================================
function UI.cargarAssets()
    if love.filesystem.getInfo("assets/titulo.png") then
        UI.imagenTitulo = love.graphics.newImage("assets/titulo.png")
    end
    if love.filesystem.getInfo("assets/titulo_mundo2_es.png") then
        UI.imagenTituloMundo2ES = love.graphics.newImage("assets/titulo_mundo2_es.png")
    end
    if love.filesystem.getInfo("assets/titulo_mundo2_en.png") then
        UI.imagenTituloMundo2EN = love.graphics.newImage("assets/titulo_mundo2_en.png")
    end

    if love.filesystem.getInfo("assets/mesa_lab.png") then
        UI.imgMesa = love.graphics.newImage("assets/mesa_lab.png")
        UI.imgMesa:setFilter("nearest", "nearest")
    end

    if love.filesystem.getInfo("assets/boton_madera.png") then
        UI.imgBotones = love.graphics.newImage("assets/boton_madera.png")
        UI.imgBotones:setFilter("nearest", "nearest")
        local bAncho = UI.imgBotones:getWidth()
        local bAlto = UI.imgBotones:getHeight()
        UI.quadBotonNormal = love.graphics.newQuad(bAncho * 0.10, bAlto * 0.18, bAncho * 0.32, bAlto * 0.15, bAncho, bAlto)
        UI.quadBotonPresionado = love.graphics.newQuad(bAncho * 0.58, bAlto * 0.18, bAncho * 0.32, bAlto * 0.15, bAncho, bAlto)
    end

    if love.filesystem.getInfo("assets/BTNS-CONFIG.png") then
        UI.imgBotonConfigES = love.graphics.newImage("assets/BTNS-CONFIG.png")
        UI.imgBotonConfigES:setFilter("nearest", "nearest")
        local w = UI.imgBotonConfigES:getWidth()
        local h = UI.imgBotonConfigES:getHeight()
        UI.quadConfigNormalES = love.graphics.newQuad(0, 0, w / 2, h, w, h)
        UI.quadConfigPresionadoES = love.graphics.newQuad(w / 2, 0, w / 2, h, w, h)
    end

    if love.filesystem.getInfo("assets/BTNS-CONFIG-EN.png") then
        UI.imgBotonConfigEN = love.graphics.newImage("assets/BTNS-CONFIG-EN.png")
        UI.imgBotonConfigEN:setFilter("nearest", "nearest")
        local w = UI.imgBotonConfigEN:getWidth()
        local h = UI.imgBotonConfigEN:getHeight()
        UI.quadConfigNormalEN = love.graphics.newQuad(0, 0, w / 2, h, w, h)
        UI.quadConfigPresionadoEN = love.graphics.newQuad(w / 2, 0, w / 2, h, w, h)
    end

    if love.filesystem.getInfo("assets/rey_bicho.png") then
        UI.imgReyBicho = love.graphics.newImage("assets/rey_bicho.png")
        UI.imgReyBicho:setFilter("linear", "linear")
        local w = UI.imgReyBicho:getWidth()
        local h = UI.imgReyBicho:getHeight()
        UI.quadReyBichoNormal = love.graphics.newQuad(0, 0, w / 2, h, w, h)
        UI.quadReyBichoPresionado = love.graphics.newQuad(w / 2, 0, w / 2, h, w, h)
    end
end


-- ============================================================================
-- [PUNTO 8: UTILIDADES Y RENDERIZADO GENERAL]
-- ============================================================================
function UI.transformarCoordenadas(x, y)
    local anchoReal = love.graphics.getWidth()
    local altoReal = love.graphics.getHeight()
    return (x / anchoReal) * UI.VIRTUAL_ANCHO, (y / altoReal) * UI.VIRTUAL_ALTO
end

function UI.puntoEnBoton(vx, vy, btn)
    return vx >= btn.x and vx <= (btn.x + btn.ancho) and vy >= btn.y and vy <= (btn.y + btn.alto)
end

function UI.limpiarFondo()
    local color = UI.modoOscuro and UI.colorOscuro or UI.colorClaro
    love.graphics.clear(color[1], color[2], color[3])
end

function UI.dibujarBoton(btn, texto, escalaTexto, Fuente)
    love.graphics.setColor(1, 1, 1)
    if UI.imgBotones and UI.quadBotonNormal and UI.quadBotonPresionado then
        local quadActual = btn.presionado and UI.quadBotonPresionado or UI.quadBotonNormal
        local _, _, qAncho, qAlto = quadActual:getViewport()
        love.graphics.draw(UI.imgBotones, quadActual, btn.x, btn.y, 0, btn.ancho / qAncho, btn.alto / qAlto)
    else
        love.graphics.setColor(btn.presionado and {0.3, 0.15, 0.05} or {0.65, 0.32, 0.18})
        love.graphics.rectangle("fill", btn.x, btn.y, btn.ancho, btn.alto, 12, 12)
    end
    
    local altoEstimado = (Fuente.img and (Fuente.img:getHeight() / 5) or 32) * escalaTexto
    local anchoTexto = Fuente.obtenerAncho(texto, escalaTexto)
    Fuente.dibujar(texto, (btn.x + (btn.ancho / 2)) - (anchoTexto / 2), (btn.y + (btn.alto / 2)) - (altoEstimado / 2) + (btn.presionado and 3 or 0), escalaTexto)
end

function UI.dibujarLabelMonedas(cantidadMonedas, Fuente)
    Fuente.dibujar(UI.getTexto("monedas") .. tostring(cantidadMonedas), 20, 90, 0.13)
end

function UI.dibujarMesaYSlots()
    love.graphics.setColor(1, 1, 1)
    if UI.imgMesa then
        love.graphics.draw(UI.imgMesa, UI.mesa.x, UI.mesa.y, 0, UI.mesa.ancho / UI.imgMesa:getWidth(), UI.mesa.alto / UI.imgMesa:getHeight())
    end
    for _, slot in ipairs(UI.slots) do
        love.graphics.setColor(0.12, 0.12, 0.18, 0.85)
        love.graphics.rectangle("fill", slot.x, slot.y, slot.ancho, slot.alto, 6, 6)
        love.graphics.setColor(0.5, 0.5, 0.6)
        love.graphics.setLineWidth(2)
        love.graphics.rectangle("line", slot.x, slot.y, slot.ancho, slot.alto, 6, 6)
    end
    love.graphics.setLineWidth(1)
end


-- ============================================================================
-- [PUNTO 9: RENDERIZADO DE DIÁLOGOS CON SALTO DE LÍNEA AUTOMÁTICO (WRAP)]
-- ============================================================================
local function dibujarTextoCentradoConWrap(mensaje, dx, dy, dw, Fuente, escala)
    local palabras = {}
    for palabra in string.gmatch(mensaje, "%S+") do
        table.insert(palabras, palabra)
    end

    local lineas = {}
    local lineaActual = ""
    for _, pal in ipairs(palabras) do
        local prueba = (lineaActual == "") and pal or (lineaActual .. " " .. pal)
        if Fuente.obtenerAncho(prueba, escala) > (dw - 40) then
            table.insert(lineas, lineaActual)
            lineaActual = pal
        else
            lineaActual = prueba
        end
    end
    if lineaActual ~= "" then table.insert(lineas, lineaActual) end

    local inicioY = dy + 50
    for i, lin in ipairs(lineas) do
        local wL = Fuente.obtenerAncho(lin, escala)
        Fuente.dibujar(lin, dx + (dw / 2) - (wL / 2), inicioY + (i - 1) * 24, escala)
    end
end

function UI.dibujarDialogoConfirmacionMundo(Fuente)
    if not UI.mostrarDialogoConfirmarMundo then return end

    love.graphics.setColor(0, 0, 0, 0.7)
    love.graphics.rectangle("fill", 0, 0, UI.VIRTUAL_ANCHO, UI.VIRTUAL_ALTO)

    local dx, dy, dw, dh = 20, 160, 320, 280
    love.graphics.setColor(0.15, 0.12, 0.18, 0.95)
    love.graphics.rectangle("fill", dx, dy, dw, dh, 12, 12)
    love.graphics.setColor(0.9, 0.6, 0.1)
    love.graphics.setLineWidth(3)
    love.graphics.rectangle("line", dx, dy, dw, dh, 12, 12)
    love.graphics.setLineWidth(1)

    local claveTexto = (UI.mundoActual == 1) and "mundo2Confirmacion" or "mundo1Confirmacion"
    local mensaje = UI.getTexto(claveTexto)
    love.graphics.setColor(1, 1, 1)

    dibujarTextoCentradoConWrap(mensaje, dx, dy, dw, Fuente, 0.065)

    UI.dibujarBoton(UI.botonSiMundo, "SI / YES", 0.07, Fuente)
    UI.dibujarBoton(UI.botonNoMundo, "NO", 0.07, Fuente)
end

function UI.dibujarDialogoMundo2(Fuente)
    if not UI.mostrarDialogoMundo2 then return end

    love.graphics.setColor(0, 0, 0, 0.7)
    love.graphics.rectangle("fill", 0, 0, UI.VIRTUAL_ANCHO, UI.VIRTUAL_ALTO)

    local dx, dy, dw, dh = 20, 140, 320, 320
    love.graphics.setColor(0.15, 0.12, 0.18, 0.95)
    love.graphics.rectangle("fill", dx, dy, dw, dh, 12, 12)
    love.graphics.setColor(0.9, 0.5, 0.1)
    love.graphics.setLineWidth(3)
    love.graphics.rectangle("line", dx, dy, dw, dh, 12, 12)
    love.graphics.setLineWidth(1)

    local mensaje = UI.getTexto("mundo2Rechazo")
    love.graphics.setColor(1, 1, 1)

    dibujarTextoCentradoConWrap(mensaje, dx, dy, dw, Fuente, 0.06)

    UI.dibujarBoton(UI.botonCerrarDialogoMundo2, "OK", 0.08, Fuente)
end

function UI.dibujarDialogoReyBicho(Fuente)
    if not UI.mostrarDialogoReyBicho then return end
    love.graphics.setColor(0, 0, 0, 0.7)
    love.graphics.rectangle("fill", 0, 0, UI.VIRTUAL_ANCHO, UI.VIRTUAL_ALTO)

    local dx, dy, dw, dh = 20, 140, 320, 320
    love.graphics.setColor(0.15, 0.12, 0.18, 0.95)
    love.graphics.rectangle("fill", dx, dy, dw, dh, 12, 12)
    love.graphics.setColor(0.8, 0.2, 0.2)
    love.graphics.setLineWidth(3)
    love.graphics.rectangle("line", dx, dy, dw, dh, 12, 12)
    love.graphics.setLineWidth(1)

    if UI.imgReyBicho and UI.quadReyBichoNormal then
        love.graphics.setColor(1, 1, 1)
        local tam = 55
        local _, _, qW, qH = UI.quadReyBichoNormal:getViewport()
        love.graphics.draw(UI.imgReyBicho, UI.quadReyBichoNormal, (UI.VIRTUAL_ANCHO / 2) - (tam / 2), dy + 12, 0, tam / qW, tam / qH)
    end

    local mensaje = UI.mensajeDialogoActual or UI.getTexto(UI.claveDialogoActual or "")
    love.graphics.setColor(1, 1, 1)

    dibujarTextoCentradoConWrap(mensaje, dx, dy + 25, dw, Fuente, 0.055)

    UI.dibujarBoton(UI.botonCerrarDialogoReyBicho, "OK", 0.08, Fuente)
end


-- ============================================================================
-- [PUNTO 10: INTERFAZ DE CONFIGURACIÓN Y PANELES]
-- ============================================================================
function UI.dibujarBotonConfig()
    love.graphics.setColor(1, 1, 1)
    local btn = UI.botonConfig
    local img = (UI.idioma == "en" and UI.imgBotonConfigEN) or UI.imgBotonConfigES or UI.imgBotonConfigEN
    local qNorm = (UI.idioma == "en" and UI.quadConfigNormalEN) or UI.quadConfigNormalES
    local qPres = (UI.idioma == "en" and UI.quadConfigPresionadoEN) or UI.quadConfigPresionadoES

    if img and qNorm and qPres then
        local qActual = btn.presionado and qPres or qNorm
        local _, _, qW = qActual:getViewport()
        love.graphics.draw(img, qActual, btn.x, btn.y, 0, btn.ancho / qW, btn.ancho / qW)
    else
        love.graphics.setColor(btn.presionado and {0.2, 0.2, 0.2} or {0.0, 0.5, 0.8})
        love.graphics.rectangle("fill", btn.x, btn.y, btn.ancho, btn.alto, 8, 8)
    end
end

function UI.dibujarBotonReyBicho()
    love.graphics.setColor(1, 1, 1)
    local btn = UI.botonReyBicho
    if UI.imgReyBicho and UI.quadReyBichoNormal and UI.quadReyBichoPresionado then
        local qActual = btn.presionado and UI.quadReyBichoPresionado or UI.quadReyBichoNormal
        local _, _, qW, qH = qActual:getViewport()
        love.graphics.draw(UI.imgReyBicho, qActual, btn.x, btn.y, 0, btn.ancho / qW, btn.alto / qW)
    else
        love.graphics.setColor(btn.presionado and {0.3, 0.3, 0.3} or {0.8, 0.2, 0.2})
        love.graphics.rectangle("fill", btn.x, btn.y, btn.ancho, btn.alto, 8, 8)
    end
end

function UI.dibujarPanelReyBicho(Fuente)
    if not UI.mostrarPanelReyBicho then return end
    local p = UI.panelReyBicho
    love.graphics.setColor(0, 0, 0, 0.6)
    love.graphics.rectangle("fill", 0, 0, UI.VIRTUAL_ANCHO, UI.VIRTUAL_ALTO)
    love.graphics.setColor(0.18, 0.15, 0.22, 0.95)
    love.graphics.rectangle("fill", p.x, p.y, p.ancho, p.alto, 12, 12)
    love.graphics.setColor(0.8, 0.65, 0.2)
    love.graphics.setLineWidth(3)
    love.graphics.rectangle("line", p.x, p.y, p.ancho, p.alto, 12, 12)
    love.graphics.setLineWidth(1)

    love.graphics.setColor(0.8, 0.2, 0.2)
    love.graphics.rectangle("fill", UI.botonCerrarPanelReyBicho.x, UI.botonCerrarPanelReyBicho.y, UI.botonCerrarPanelReyBicho.ancho, UI.botonCerrarPanelReyBicho.alto, 4, 4)
    love.graphics.setColor(1, 1, 1)
    Fuente.dibujar("X", UI.botonCerrarPanelReyBicho.x + 8, UI.botonCerrarPanelReyBicho.y + 6, 0.07)

    local titulo = UI.getTexto("panelTitulo")
    Fuente.dibujar(titulo, (UI.VIRTUAL_ANCHO / 2) - (Fuente.obtenerAncho(titulo, 0.08) / 2), p.y + 15, 0.08)

    local ct = UI.cajaTextoReyBicho
    love.graphics.setColor(0.1, 0.1, 0.1, 0.9)
    love.graphics.rectangle("fill", ct.x, ct.y, ct.ancho, ct.alto, 6, 6)
    love.graphics.setColor(ct.enfocado and {0.2, 0.7, 0.3} or {0.6, 0.6, 0.7})
    love.graphics.rectangle("line", ct.x, ct.y, ct.ancho, ct.alto, 6, 6)

    local textoMostrar = (ct.texto ~= "") and ct.texto or UI.getTexto("ingresarTexto")
    love.graphics.setColor(1, 1, 1)
    Fuente.dibujar(textoMostrar, ct.x + 10, ct.y + 8, 0.065)
    UI.dibujarBoton(UI.botonAccionReyBicho, UI.getTexto("accionBoton"), 0.08, Fuente)
end

function UI.dibujarSlider(slider, porcentaje, titulo, Fuente)
    local valorPct = math.floor((porcentaje * 100) + 0.5)
    Fuente.dibujar(titulo .. " " .. tostring(valorPct) .. "%", slider.x, slider.y - 18, 0.075)
    love.graphics.setColor(0.2, 0.2, 0.2, 0.8)
    love.graphics.rectangle("fill", slider.x, slider.y, slider.ancho, slider.alto, 8, 8)
    love.graphics.setColor(0.2, 0.7, 0.3)
    love.graphics.rectangle("fill", slider.x, slider.y, slider.ancho * porcentaje, slider.alto, 8, 8)
    love.graphics.setColor(0.9, 0.9, 0.9)
    love.graphics.circle("fill", slider.x + (slider.ancho * porcentaje), slider.y + (slider.alto / 2), 10)
end

function UI.dibujarSwitch(Fuente)
    local sw = UI.switchModoOscuro
    local titulo = UI.getTexto("modoOscuro")
    local wT = Fuente.obtenerAncho(titulo, 0.07)
    Fuente.dibujar(titulo, (UI.VIRTUAL_ANCHO / 2) - (wT / 2), sw.y - 18, 0.07)

    love.graphics.setColor(UI.modoOscuro and {0.2, 0.6, 0.3} or {0.4, 0.4, 0.4})
    love.graphics.rectangle("fill", sw.x, sw.y, sw.ancho, sw.alto, sw.alto / 2, sw.alto / 2)

    local radio = (sw.alto / 2) - 3
    local posX = UI.modoOscuro and (sw.x + sw.ancho - radio - 3) or (sw.x + radio + 3)
    local posY = sw.y + (sw.alto / 2)

    love.graphics.setColor(1, 1, 1)
    love.graphics.circle("fill", posX, posY, radio)
end

function UI.dibujarSwitchSaltarAnimaciones(Fuente)
    local sw = UI.switchSaltarAnimaciones
    local titulo = UI.getTexto("saltarAnimaciones")
    local wT = Fuente.obtenerAncho(titulo, 0.07)
    Fuente.dibujar(titulo, (UI.VIRTUAL_ANCHO / 2) - (wT / 2), sw.y - 18, 0.07)

    love.graphics.setColor(UI.saltarAnimaciones and {0.2, 0.6, 0.3} or {0.4, 0.4, 0.4})
    love.graphics.rectangle("fill", sw.x, sw.y, sw.ancho, sw.alto, sw.alto / 2, sw.alto / 2)

    local radio = (sw.alto / 2) - 3
    local posX = UI.saltarAnimaciones and (sw.x + sw.ancho - radio - 3) or (sw.x + radio + 3)
    local posY = sw.y + (sw.alto / 2)

    love.graphics.setColor(1, 1, 1)
    love.graphics.circle("fill", posX, posY, radio)
end

function UI.dibujarSwitchMostrarDatos(Fuente)
    local sw = UI.switchMostrarDatos
    local titulo = UI.getTexto("mostrarDatos")
    local wT = Fuente.obtenerAncho(titulo, 0.07)
    Fuente.dibujar(titulo, (UI.VIRTUAL_ANCHO / 2) - (wT / 2), sw.y - 18, 0.07)

    love.graphics.setColor(UI.mostrarDatosEncima and {0.2, 0.6, 0.3} or {0.4, 0.4, 0.4})
    love.graphics.rectangle("fill", sw.x, sw.y, sw.ancho, sw.alto, sw.alto / 2, sw.alto / 2)

    local radio = (sw.alto / 2) - 3
    local posX = UI.mostrarDatosEncima and (sw.x + sw.ancho - radio - 3) or (sw.x + radio + 3)
    local posY = sw.y + (sw.alto / 2)

    love.graphics.setColor(1, 1, 1)
    love.graphics.circle("fill", posX, posY, radio)
end

function UI.dibujarSwitchMostrarLogos(Fuente)
    local sw = UI.switchMostrarLogos
    local titulo = UI.getTexto("mostrarLogos")
    local wT = Fuente.obtenerAncho(titulo, 0.07)
    Fuente.dibujar(titulo, (UI.VIRTUAL_ANCHO / 2) - (wT / 2), sw.y - 18, 0.07)

    love.graphics.setColor(UI.mostrarLogos and {0.2, 0.6, 0.3} or {0.4, 0.4, 0.4})
    love.graphics.rectangle("fill", sw.x, sw.y, sw.ancho, sw.alto, sw.alto / 2, sw.alto / 2)

    local radio = (sw.alto / 2) - 3
    local posX = UI.mostrarLogos and (sw.x + sw.ancho - radio - 3) or (sw.x + radio + 3)
    local posY = sw.y + (sw.alto / 2)

    love.graphics.setColor(1, 1, 1)
    love.graphics.circle("fill", posX, posY, radio)
end

function UI.dibujarSelectorIdioma(Fuente)
    local titulo = UI.getTexto("idioma")
    local wT = Fuente.obtenerAncho(titulo, 0.07)
    Fuente.dibujar(titulo, (UI.VIRTUAL_ANCHO / 2) - (wT / 2), UI.botonLangES.y - 18, 0.07)

    love.graphics.setColor(UI.idioma == "es" and {0.2, 0.6, 0.3} or {0.3, 0.3, 0.35})
    love.graphics.rectangle("fill", UI.botonLangES.x, UI.botonLangES.y, UI.botonLangES.ancho, UI.botonLangES.alto, 6, 6)
    love.graphics.setColor(1, 1, 1)
    Fuente.dibujar("ES", UI.botonLangES.x + 20, UI.botonLangES.y + 7, 0.075)

    love.graphics.setColor(UI.idioma == "en" and {0.2, 0.6, 0.3} or {0.3, 0.3, 0.35})
    love.graphics.rectangle("fill", UI.botonLangEN.x, UI.botonLangEN.y, UI.botonLangEN.ancho, UI.botonLangEN.alto, 6, 6)
    love.graphics.setColor(1, 1, 1)
    Fuente.dibujar("EN", UI.botonLangEN.x + 20, UI.botonLangEN.y + 7, 0.075)
end

return UI
