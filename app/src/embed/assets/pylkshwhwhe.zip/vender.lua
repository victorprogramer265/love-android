local Vender = {}

-- Movido aún más a la izquierda (x pasa de 50 a 20)
Vender.zona = { x = 20, y = 430, ancho = 180, alto = 160 }
Vender.img = nil
Vender.quadES = nil
Vender.quadEN = nil
Vender.personaje = nil 

function Vender.cargarAssets()
    if love.filesystem.getInfo("assets/puesto_venta.png") then
        Vender.img = love.graphics.newImage("assets/puesto_venta.png")
        Vender.img:setFilter("nearest", "nearest")
        
        local anchoTotal = Vender.img:getWidth()
        local altoTotal = Vender.img:getHeight()
        local mitadAncho = anchoTotal / 2
        
        Vender.quadES = love.graphics.newQuad(0, 0, mitadAncho, altoTotal, anchoTotal, altoTotal)
        Vender.quadEN = love.graphics.newQuad(mitadAncho, 0, mitadAncho, altoTotal, anchoTotal, altoTotal)
    end
end

function Vender.dibujarZona(Fuente, UI)
    local z = Vender.zona
    local idiomaActual = (UI and UI.idioma) or "es"
    
    if Vender.img then
        love.graphics.setColor(1, 1, 1, 1)
        local quadActual = (idiomaActual == "en") and Vender.quadEN or Vender.quadES
        
        love.graphics.draw(Vender.img, quadActual, z.x, z.y, 0, z.ancho / (Vender.img:getWidth() / 2), z.alto / Vender.img:getHeight())
    else
        love.graphics.setColor(0.8, 0.2, 0.2, 0.3)
        love.graphics.rectangle("fill", z.x, z.y, z.ancho, z.alto, 10, 10)
        love.graphics.setColor(0.9, 0.3, 0.3, 1)
        love.graphics.setLineWidth(2)
        love.graphics.rectangle("line", z.x, z.y, z.ancho, z.alto, 10, 10)

        love.graphics.setColor(1, 1, 1, 1)
        local texto = (idiomaActual == "en") and "DRAG TO SELL" or "ARRASTRA PARA VENDER"
        local wTexto = Fuente.obtenerAncho(texto, 0.08)
        Fuente.dibujar(texto, z.x + (z.ancho/2) - (wTexto/2), z.y + (z.alto/2) - 10, 0.08)
    end
end

function Vender.dibujarModal(Fuente, UI)
    if not Vender.personaje then return end
    
    local idiomaActual = (UI and UI.idioma) or "es"
    local p = Vender.personaje
    -- Panel modal también más a la izquierda (x pasa de 20 a 10)
    local panel = { x = 10, y = 200, ancho = 280, alto = 180 }

    love.graphics.setColor(0.1, 0.1, 0.15, 0.95)
    love.graphics.rectangle("fill", panel.x, panel.y, panel.ancho, panel.alto, 12, 12)
    love.graphics.setColor(0.9, 0.2, 0.2, 1.0)
    love.graphics.setLineWidth(3)
    love.graphics.rectangle("line", panel.x, panel.y, panel.ancho, panel.alto, 12, 12)

    love.graphics.setColor(1, 1, 1, 1.0)
    local valorVenta = math.floor(p.cc / 2)
    local textoVender = (idiomaActual == "en") and "SELL " .. string.upper(p.nombre) .. "?" or "VENDER A " .. string.upper(p.nombre) .. "?"
    Fuente.dibujar(textoVender, panel.x + 20, panel.y + 20, 0.06)
    
    love.graphics.setColor(0.4, 0.9, 0.4, 1.0)
    local textoObtienes = (idiomaActual == "en") and "YOU GET: $" .. tostring(valorVenta) or "OBTIENES: $" .. tostring(valorVenta)
    Fuente.dibujar(textoObtienes, panel.x + 30, panel.y + 60, 0.07)

    love.graphics.setColor(0.2, 0.7, 0.3, 1.0)
    love.graphics.rectangle("fill", panel.x + 30, panel.y + 120, 100, 40, 8, 8)
    love.graphics.setColor(1, 1, 1, 1.0)
    local txtSi = (idiomaActual == "en") and "YES" or "SI"
    Fuente.dibujar(txtSi, panel.x + 65, panel.y + 130, 0.08)

    love.graphics.setColor(0.8, 0.2, 0.2, 1.0)
    love.graphics.rectangle("fill", panel.x + 150, panel.y + 120, 100, 40, 8, 8)
    love.graphics.setColor(1, 1, 1, 1.0)
    local txtNo = (idiomaActual == "en") and "NO" or "NO"
    Fuente.dibujar(txtNo, panel.x + 185, panel.y + 130, 0.08)
end

function Vender.verificarClickModal(vx, vy, UI, datosUsuario, PersonajesRef, Audio)
    if not Vender.personaje then return false end
    
    -- Ajustado a la nueva posición del panel (x = 10)
    local panel = { x = 10, y = 200, ancho = 280, alto = 180 }
    local btnSi = { x = panel.x + 30, y = panel.y + 120, ancho = 100, alto = 40 }
    local btnNo = { x = panel.x + 150, y = panel.y + 120, ancho = 100, alto = 40 }

    if UI.puntoEnBoton(vx, vy, btnSi) then
        local valorVenta = math.floor(Vender.personaje.cc / 2)
        datosUsuario.monedas = (datosUsuario.monedas or 0) + valorVenta

        if Vender.personaje.slotId and UI.slots[Vender.personaje.slotId] then
            UI.slots[Vender.personaje.slotId].contenido = nil
        end

        for i, inst in ipairs(PersonajesRef.instancias) do
            if inst == Vender.personaje then
                table.remove(PersonajesRef.instancias, i)
                break
            end
        end

        Vender.personaje = nil
        if Audio and Audio.reproducirClick then Audio.reproducirClick() end
        return true

    elseif UI.puntoEnBoton(vx, vy, btnNo) then
        Vender.personaje = nil
        if Audio and Audio.reproducirClick then Audio.reproducirClick() end
        return true
    end
    
    return true 
end

function Vender.verificarDrop(vx, vy, personajeArrastrado, UI)
    if UI.puntoEnBoton(vx, vy, Vender.zona) then
        Vender.personaje = personajeArrastrado
        
        if personajeArrastrado.ubicacion == "mesa" and personajeArrastrado.slotId and UI.slots and UI.slots[personajeArrastrado.slotId] then
            local slot = UI.slots[personajeArrastrado.slotId]
            personajeArrastrado.x = slot.x + (slot.ancho - personajeArrastrado.ancho) / 2
            personajeArrastrado.y = slot.y + (slot.alto - personajeArrastrado.alto) / 2
        end
        return true
    end
    return false
end

return Vender
