-- ============================================================================
-- [PUNTO 1: IMPORTACIÓN DE MÓDULOS Y VARIABLES GLOBALES]
-- ============================================================================
local Mochila = require("mochila")
local SaveSystem = require("save_system")
local UI = require("UI_MENU_AND_MORE")
local Tienda = require("tienda")
local Fuente = require("fuente")
local Audio = require("audio")
local Personajes = require("personajes")
local Vender = require("vender")
local Cargando = require("cargando")
local Adn = require("adn")
local CEReyEscarabajo = require("CE_REYESCARABAJO")

local datosUsuario = {}

local faseActual = "cargando"
local alfaTransicion = 0
local velocidadTransicion = 1 / 0.5 
local estadoDestinoDespuesDeTransicion = "menu"

local function redondear(valor, paso)
    paso = paso or 0.05
    return math.floor((valor / paso) + 0.5) * paso
end


-- ============================================================================
-- [PUNTO 2: SISTEMA DE GUARDADO INTEGRAL DE DATOS]
-- ============================================================================
local function guardarTodo()
    datosUsuario.monedas = datosUsuario.monedas or 0
    datosUsuario.acumuladorMPS = datosUsuario.acumuladorMPS or 0
    datosUsuario.volumenMusica = redondear(Audio.volumenMusica, 0.05)
    datosUsuario.volumenFX = redondear(Audio.volumenFX, 0.05)
    datosUsuario.modoOscuro = UI.modoOscuro
    datosUsuario.saltarAnimaciones = UI.saltarAnimaciones
    datosUsuario.mostrarDatosEncima = UI.mostrarDatosEncima 
    datosUsuario.mostrarLogos = UI.mostrarLogos
    datosUsuario.idioma = UI.idioma
    datosUsuario.mundoActual = UI.mundoActual
    datosUsuario.mundo2Desbloqueado = datosUsuario.mundo2Desbloqueado or false

    -- Guardado independiente por mundo para evitar cruces de personajes
    Personajes.guardarDatosPorMundo(UI, datosUsuario)
    SaveSystem.guardar(datosUsuario)
end


-- ============================================================================
-- [PUNTO 3: INICIALIZACIÓN DEL JUEGO (LOVE.LOAD)]
-- ============================================================================
function love.load()
    love.window.setMode(UI.VIRTUAL_ANCHO, UI.VIRTUAL_ALTO, {resizable = true})
    
    Fuente.cargar()
    UI.cargarAssets()
    Tienda.cargarAssets()
    Mochila.cargarAssets()
    Audio.cargar()
    Personajes.cargarAssets()
    Vender.cargarAssets()
    Cargando.cargarAssets()
    
    datosUsuario = SaveSystem.cargar() or {}
    if type(datosUsuario) ~= "table" then datosUsuario = {} end
    if type(datosUsuario.monedas) ~= "number" then datosUsuario.monedas = 100 end

    if datosUsuario.mundoActual then
        UI.cambiarMundo(datosUsuario.mundoActual)
    end

    if type(datosUsuario.volumenMusica) == "number" then
        Audio.actualizarVolumenMusica(redondear(datosUsuario.volumenMusica, 0.05))
    end
    if type(datosUsuario.volumenFX) == "number" then
        Audio.actualizarVolumenFX(redondear(datosUsuario.volumenFX, 0.05))
    end
    if type(datosUsuario.modoOscuro) == "boolean" then UI.modoOscuro = datosUsuario.modoOscuro end
    if type(datosUsuario.saltarAnimaciones) == "boolean" then UI.saltarAnimaciones = datosUsuario.saltarAnimaciones end
    if type(datosUsuario.mostrarDatosEncima) == "boolean" then UI.mostrarDatosEncima = datosUsuario.mostrarDatosEncima end 
    if type(datosUsuario.mostrarLogos) == "boolean" then UI.mostrarLogos = datosUsuario.mostrarLogos end
    if type(datosUsuario.idioma) == "string" then UI.idioma = datosUsuario.idioma end

    -- Carga los personajes correspondientes al mundo actual al iniciar
    if (datosUsuario.personajesMundo1 and #datosUsuario.personajesMundo1 > 0) or (datosUsuario.personajesMundo2 and #datosUsuario.personajesMundo2 > 0) then
        Personajes.cargarDatosPorMundo(UI, datosUsuario)
    elseif datosUsuario.personajes and #datosUsuario.personajes > 0 then
        Personajes.cargarDatos(datosUsuario.personajes, UI)
    else
        local p1 = Personajes.crearInstancia(1, 0, 0, "mesa")
        p1.slotId = 1
        UI.slots[1].contenido = p1
        p1.x = UI.slots[1].x + (UI.slots[1].ancho - (p1.ancho or 32)) / 2
        p1.y = UI.slots[1].y + (UI.slots[1].alto - (p1.alto or 32)) / 2
        
        guardarTodo()
    end
end


-- ============================================================================
-- [PUNTO 4: GESTIÓN DE TRANSICIONES DE ESTADO]
-- ============================================================================
local function iniciarTransicion(siguienteEstado)
    if UI.saltarAnimaciones then
        Cargando.activo = false
        UI.estadoJuego = siguienteEstado
        faseActual = siguienteEstado
        alfaTransicion = 0
        return
    end

    faseActual = "transicion"
    estadoDestinoDespuesDeTransicion = siguienteEstado
    alfaTransicion = 0
end


-- ============================================================================
-- [PUNTO 5: BUCLE DE ACTUALIZACIÓN (LOVE.UPDATE)]
-- ============================================================================
function love.update(dt)
    Audio.update(dt)

    if faseActual == "cargando" then
        Cargando.update(dt, UI)
        if not Cargando.activo then
            if UI.saltarAnimaciones or not UI.mostrarLogos then
                UI.estadoJuego = "menu"
                faseActual = "menu"
                alfaTransicion = 0
            else
                UI.estadoJuego = "menu"
                faseActual = "abriendo"
                alfaTransicion = 1
                estadoDestinoDespuesDeTransicion = "menu"
            end
        end
        return
    end

    if faseActual == "transicion" then
        alfaTransicion = alfaTransicion + (velocidadTransicion * dt)
        if alfaTransicion >= 1 then
            alfaTransicion = 1
            UI.estadoJuego = estadoDestinoDespuesDeTransicion
            faseActual = "abriendo"
        end
        return
    end

    if faseActual == "abriendo" then
        alfaTransicion = alfaTransicion - (velocidadTransicion * dt)
        if alfaTransicion <= 0 then
            alfaTransicion = 0
            faseActual = UI.estadoJuego
        end
    end

    if UI.estadoJuego == "juego" then
        Personajes.update(dt, UI, datosUsuario)
        Adn.update(dt, datosUsuario)
    end

    if love.mouse.isDown(1) then
        local x, y = love.mouse.getPosition()
        local vx, vy = UI.transformarCoordenadas(x, y)

        if UI.sliderMusica.arrastrando then
            local pct = (vx - UI.sliderMusica.x) / UI.sliderMusica.ancho
            pct = math.max(0, math.min(1, pct))
            Audio.actualizarVolumenMusica(redondear(pct, 0.05))
        elseif UI.sliderFX.arrastrando then
            local pct = (vx - UI.sliderFX.x) / UI.sliderFX.ancho
            pct = math.max(0, math.min(1, pct))
            Audio.actualizarVolumenFX(redondear(pct, 0.05))
        end
    end
end


-- ============================================================================
-- [PUNTO 6: ENTRADAS DE TEXTO Y TECLADO]
-- ============================================================================
function love.textinput(t)
    if UI.mostrarPanelReyBicho and UI.cajaTextoReyBicho.enfocado then
        UI.cajaTextoReyBicho.texto = UI.cajaTextoReyBicho.texto .. t
    end
end

function love.keypressed(key)
    if UI.mostrarPanelReyBicho and UI.cajaTextoReyBicho.enfocado then
        if key == "backspace" then
            local byteoffset = utf8 and utf8.offset or nil
            if byteoffset then
                local code = UI.cajaTextoReyBicho.texto
                local set = utf8.offset(code, -1)
                if set then
                    UI.cajaTextoReyBicho.texto = string.sub(code, 1, set - 1)
                end
            else
                UI.cajaTextoReyBicho.texto = string.sub(UI.cajaTextoReyBicho.texto, 1, -2)
            end
        end
    end
end


-- ============================================================================
-- [PUNTO 7: EVENTOS DE CLIC (LOVE.MOUSEPRESSED)]
-- ============================================================================
function love.mousepressed(x, y, button, isTouch)
    if faseActual == "cargando" or faseActual == "transicion" or faseActual == "abriendo" then return end

    local vx, vy = UI.transformarCoordenadas(x, y)

    if UI.mostrarDialogoConfirmarMundo then
        if UI.puntoEnBoton(vx, vy, UI.botonSiMundo) then UI.botonSiMundo.presionado = true Audio.reproducirClick() end
        if UI.puntoEnBoton(vx, vy, UI.botonNoMundo) then UI.botonNoMundo.presionado = true Audio.reproducirClick() end
        return
    end

    if UI.mostrarDialogoReyBicho then
        if UI.puntoEnBoton(vx, vy, UI.botonCerrarDialogoReyBicho) then
            UI.botonCerrarDialogoReyBicho.presionado = true
            Audio.reproducirClick()
        end
        return
    end

    if UI.mostrarDialogoMundo2 then
        if UI.puntoEnBoton(vx, vy, UI.botonCerrarDialogoMundo2) then
            UI.botonCerrarDialogoMundo2.presionado = true
            Audio.reproducirClick()
        end
        return
    end

    if UI.mostrarPanelReyBicho then
        if UI.puntoEnBoton(vx, vy, UI.cajaTextoReyBicho) then
            UI.cajaTextoReyBicho.enfocado = true
            love.keyboard.setTextInput(true)
        else
            UI.cajaTextoReyBicho.enfocado = false
            love.keyboard.setTextInput(false)
        end

        if UI.puntoEnBoton(vx, vy, UI.botonCerrarPanelReyBicho) then
            UI.botonCerrarPanelReyBicho.presionado = true
            Audio.reproducirClick()
        elseif UI.puntoEnBoton(vx, vy, UI.botonAccionReyBicho) then
            UI.botonAccionReyBicho.presionado = true
            Audio.reproducirClick()
        end
        return
    end
    
    if UI.estadoJuego == "juego" then
        if Adn.clicBotonDar(vx, vy, datosUsuario, Audio) then
            guardarTodo()
            return
        end

        if Mochila.abierta then
            if UI.puntoEnBoton(vx, vy, Mochila.botonCerrar) then
                Mochila.botonCerrar.presionado = true
                Audio.reproducirClick()
                return
            end
            if Mochila.mousepressed(vx, vy, button, UI, Personajes, Audio) then
                return
            end
        end

        if Personajes.mousepressed(vx, vy, button, UI, datosUsuario, Audio, Mochila) then
            guardarTodo()
            return
        end
    end

    if UI.estadoJuego == "menu" then
        if UI.puntoEnBoton(vx, vy, UI.botonJugar) then 
            UI.botonJugar.presionado = true 
            Audio.reproducirClick()
        elseif UI.puntoEnBoton(vx, vy, UI.botonMundo2) then 
            UI.botonMundo2.presionado = true 
            Audio.reproducirClick()
        elseif UI.puntoEnBoton(vx, vy, UI.botonConfig) then 
            UI.botonConfig.presionado = true 
            Audio.reproducirClick()
        end

    elseif UI.estadoJuego == "juego" then
        if UI.puntoEnBoton(vx, vy, UI.botonVolverMenu) then 
            UI.botonVolverMenu.presionado = true 
            Audio.reproducirClick()
        elseif UI.puntoEnBoton(vx, vy, Mochila.botonHUD) then
            Mochila.botonHUD.presionado = true
            Audio.reproducirClick()
        elseif UI.puntoEnBoton(vx, vy, Tienda.boton) then
            Tienda.boton.presionado = true
            Audio.reproducirClick()
        end

    elseif UI.estadoJuego == "configuracion" then
        if UI.puntoEnBoton(vx, vy, UI.botonVolverMenu) then
            UI.botonVolverMenu.presionado = true 
            Audio.reproducirClick()
        elseif UI.puntoEnBoton(vx, vy, UI.botonReyBicho) then
            UI.botonReyBicho.presionado = true
            Audio.reproducirClick()
        elseif UI.puntoEnBoton(vx, vy, UI.sliderMusica) then
            UI.sliderMusica.arrastrando = true
        elseif UI.puntoEnBoton(vx, vy, UI.sliderFX) then
            UI.sliderFX.arrastrando = true
        elseif UI.puntoEnBoton(vx, vy, UI.switchModoOscuro) then
            UI.modoOscuro = not UI.modoOscuro
            Audio.reproducirClick()
            guardarTodo()
        elseif UI.puntoEnBoton(vx, vy, UI.switchSaltarAnimaciones) then
            UI.saltarAnimaciones = not UI.saltarAnimaciones
            Audio.reproducirClick()
            guardarTodo()
        elseif UI.puntoEnBoton(vx, vy, UI.switchMostrarDatos) then 
            UI.mostrarDatosEncima = not UI.mostrarDatosEncima
            Audio.reproducirClick()
            guardarTodo()
        elseif UI.puntoEnBoton(vx, vy, UI.switchMostrarLogos) then 
            UI.mostrarLogos = not UI.mostrarLogos
            Audio.reproducirClick()
            guardarTodo()
        elseif UI.puntoEnBoton(vx, vy, UI.botonLangES) then
            UI.idioma = "es"
            Audio.reproducirClick()
            guardarTodo()
        elseif UI.puntoEnBoton(vx, vy, UI.botonLangEN) then
            UI.idioma = "en"
            Audio.reproducirClick()
            guardarTodo()
        end
    end
end


-- ============================================================================
-- [PUNTO 8: MOVIMIENTO Y SOLTADO DE CLICS (MOUSERELEASED)]
-- ============================================================================
function love.mousemoved(x, y, dx, dy)
    if faseActual == "cargando" or faseActual == "transicion" or faseActual == "abriendo" then return end
    local vx, vy = UI.transformarCoordenadas(x, y)
    if UI.estadoJuego == "juego" and Mochila.abierta then
        Mochila.mousemoved(vx, vy, dy)
    end
end

function love.mousereleased(x, y, button, isTouch)
    if faseActual == "cargando" or faseActual == "transicion" or faseActual == "abriendo" then return end

    local vx, vy = UI.transformarCoordenadas(x, y)

    if UI.mostrarDialogoConfirmarMundo then
        if UI.botonSiMundo.presionado then
            UI.botonSiMundo.presionado = false
            UI.mostrarDialogoConfirmarMundo = false
            
            -- Guardamos el mundo actual antes de cambiar
            guardarTodo()
            
            -- Cambiamos de mundo
            UI.cambiarMundo(UI.mundoActual == 1 and 2 or 1)
            
            -- Cargamos las criaturas correspondientes al nuevo mundo
            Personajes.cargarDatosPorMundo(UI, datosUsuario)
            
            guardarTodo()
        elseif UI.botonNoMundo.presionado then
            UI.botonNoMundo.presionado = false
            UI.mostrarDialogoConfirmarMundo = false
        end
        return
    end

    if UI.mostrarDialogoReyBicho then
        if UI.botonCerrarDialogoReyBicho.presionado then
            UI.botonCerrarDialogoReyBicho.presionado = false
            UI.mostrarDialogoReyBicho = false
        end
        return
    end

    if UI.mostrarDialogoMundo2 then
        if UI.botonCerrarDialogoMundo2.presionado then
            UI.botonCerrarDialogoMundo2.presionado = false
            UI.mostrarDialogoMundo2 = false
        end
        return
    end

    if UI.mostrarPanelReyBicho then
        if UI.botonCerrarPanelReyBicho.presionado then
            UI.botonCerrarPanelReyBicho.presionado = false
            UI.mostrarPanelReyBicho = false
            love.keyboard.setTextInput(false)
            Audio.detenerMusicaRey() 
        elseif UI.botonAccionReyBicho.presionado then
            UI.botonAccionReyBicho.presionado = false

            local exito, mensaje = CEReyEscarabajo.validarCodigo(UI.cajaTextoReyBicho.texto, UI.idioma, datosUsuario, Personajes)

            UI.claveDialogoActual = nil
            UI.mensajeDialogoActual = mensaje
            UI.mostrarDialogoReyBicho = true

            if exito then
                UI.cajaTextoReyBicho.texto = ""
                guardarTodo()
            end
        end
        return
    end
    
    if UI.estadoJuego == "juego" then
        Mochila.mousereleased(button)
        Personajes.mousereleased(vx, vy, button, UI, Mochila)
        guardarTodo()
    end

    if UI.sliderMusica.arrastrando or UI.sliderFX.arrastrando then
        guardarTodo()
    end

    UI.sliderMusica.arrastrando = false
    UI.sliderFX.arrastrando = false

    if UI.estadoJuego == "menu" then
        if UI.botonJugar.presionado then
            UI.botonJugar.presionado = false
            if UI.puntoEnBoton(vx, vy, UI.botonJugar) then 
                iniciarTransicion("juego")
            end
        elseif UI.botonMundo2.presionado then
            UI.botonMundo2.presionado = false
            if UI.puntoEnBoton(vx, vy, UI.botonMundo2) then 
                if UI.mundoActual == 1 then
                    if datosUsuario.mundo2Desbloqueado then
                        UI.mostrarDialogoConfirmarMundo = true
                    else
                        local monedasActuales = datosUsuario.monedas or 0
                        if monedasActuales >= 20000 then
                            datosUsuario.monedas = monedasActuales - 20000
                            datosUsuario.mundo2Desbloqueado = true
                            guardarTodo()
                            UI.mostrarDialogoConfirmarMundo = true
                        else
                            UI.mostrarDialogoMundo2 = true
                        end
                    end
                else
                    UI.mostrarDialogoConfirmarMundo = true
                end
            end
        elseif UI.botonConfig.presionado then
            UI.botonConfig.presionado = false
            if UI.puntoEnBoton(vx, vy, UI.botonConfig) then UI.estadoJuego = "configuracion" end
        end

    elseif UI.estadoJuego == "juego" then
        if Mochila.abierta then
            if Mochila.botonCerrar and Mochila.botonCerrar.presionado then
                Mochila.botonCerrar.presionado = false
                if UI.puntoEnBoton(vx, vy, Mochila.botonCerrar) then
                    Mochila.abierta = false
                end
            end
        end

        if UI.botonVolverMenu.presionado then
            UI.botonVolverMenu.presionado = false
            if UI.puntoEnBoton(vx, vy, UI.botonVolverMenu) then 
                iniciarTransicion("menu") 
            end
        elseif Mochila.botonHUD.presionado then
            Mochila.botonHUD.presionado = false
            if UI.puntoEnBoton(vx, vy, Mochila.botonHUD) then
                Mochila.toggle()
            end
        elseif Tienda.boton.presionado then
            Tienda.boton.presionado = false
            if UI.puntoEnBoton(vx, vy, Tienda.boton) then
                Personajes.tiendaAbierta = not Personajes.tiendaAbierta
            end
        end

    elseif UI.estadoJuego == "configuracion" then
        if UI.botonVolverMenu.presionado then
            UI.botonVolverMenu.presionado = false
            if UI.puntoEnBoton(vx, vy, UI.botonVolverMenu) then UI.estadoJuego = "menu" end
        elseif UI.botonReyBicho.presionado then
            UI.botonReyBicho.presionado = false
            if UI.puntoEnBoton(vx, vy, UI.botonReyBicho) then
                local monedasActuales = datosUsuario.monedas or 0
                
                if monedasActuales >= 10000 then
                    UI.mostrarPanelReyBicho = true
                    Audio.reproducirMusicaRey() 
                else
                    UI.intentosAccesoReyBicho = UI.intentosAccesoReyBicho + 1
                    
                    UI.mensajeDialogoActual = nil
                    if UI.intentosAccesoReyBicho == 1 then
                        UI.claveDialogoActual = "reyBichoRechazo1"
                    else
                        UI.claveDialogoActual = "reyBichoRechazo2"
                    end
                    UI.mostrarDialogoReyBicho = true
                end
            end
        end
    end
end

function love.wheelmoved(x, y)
    if faseActual == "cargando" or faseActual == "transicion" or faseActual == "abriendo" then return end
    if UI.estadoJuego == "juego" then
        if Mochila.abierta then
            Mochila.wheelmoved(x, y)
        elseif Personajes.tiendaAbierta then
            Personajes.wheelmoved(x, y)
        end
    end
end

function love.quit()
    guardarTodo()
end



-- ============================================================================
-- [PUNTO 9: RENDERIZADO VISUAL GENERAL (LOVE.DRAW)]
-- ============================================================================
function love.draw()
    local anchoReal = love.graphics.getWidth()
    local altoReal = love.graphics.getHeight()
    
    UI.limpiarFondo()
    
    love.graphics.push()
    love.graphics.scale(anchoReal / UI.VIRTUAL_ANCHO, altoReal / UI.VIRTUAL_ALTO)

    if faseActual == "cargando" then
        Cargando.dibujar(UI)
        love.graphics.pop()
        return
    end

    if UI.estadoJuego == "menu" then
        local imgLogo = UI.imagenTitulo
        if UI.mundoActual == 2 then
            if UI.idioma == "en" and UI.imagenTituloMundo2EN then
                imgLogo = UI.imagenTituloMundo2EN
            elseif UI.imagenTituloMundo2ES then
                imgLogo = UI.imagenTituloMundo2ES
            end
        end

        if imgLogo then
            local imgAncho = imgLogo:getWidth()
            local escala = 280 / imgAncho
            love.graphics.setColor(1, 1, 1)
            love.graphics.draw(imgLogo, (UI.VIRTUAL_ANCHO / 2) - ((imgAncho * escala) / 2), 80, 0, escala, escala)
        end
        
        UI.dibujarBotonConfig()
        UI.dibujarBoton(UI.botonJugar, string.upper(UI.getTexto("jugar")), 0.12, Fuente)
        
        local textoBotonMundo = (UI.mundoActual == 1) and UI.getTexto("mundo2") or UI.getTexto("mundo1")
        UI.dibujarBoton(UI.botonMundo2, string.upper(textoBotonMundo), 0.10, Fuente)

        UI.dibujarDialogoConfirmacionMundo(Fuente)
        UI.dibujarDialogoMundo2(Fuente)

    elseif UI.estadoJuego == "juego" then
        UI.dibujarBoton(UI.botonVolverMenu, string.upper(UI.getTexto("menu")), 0.08, Fuente)
        
        Mochila.dibujarBotonHUD()
        Tienda.dibujarBotonHUD(UI, Fuente)
        
        -- Fix visual de monedas: Redondeamos siempre hacia abajo el valor numérico para evitar desbordes visuales fantasma
        local monedasVisuales = math.floor(datosUsuario.monedas or 0)
        UI.dibujarLabelMonedas(monedasVisuales, Fuente)

        -- Si estamos en el Mundo 2, mostramos la etiqueta con la ganancia pasiva real del Mundo 1
        if UI.mundoActual == 2 then
            local mpsPasivoM1 = Personajes.calcularMPSMundo1(datosUsuario)
            local textoPasivo = "MUNDO 1 MPS: +" .. tostring(math.floor(mpsPasivoM1))
            Fuente.dibujar(textoPasivo, 20, 115, 0.08)
        end

        if not Mochila.abierta then
            UI.dibujarMesaYSlots()
            
            if not Personajes.tiendaAbierta then
                Vender.dibujarZona(Fuente, UI)
                Adn.dibujar(Fuente, UI)
            end
        end

        Personajes.dibujar(UI, Fuente, datosUsuario, Mochila)
        Mochila.dibujar(Fuente, UI, Personajes)
        Vender.dibujarModal(Fuente)

    elseif UI.estadoJuego == "configuracion" then
        UI.dibujarBoton(UI.botonVolverMenu, string.upper(UI.getTexto("menu")), 0.08, Fuente)
        
        UI.dibujarBotonReyBicho()

        local tituloCfg = string.upper(UI.getTexto("configuracion"))
        local wCfg = Fuente.obtenerAncho(tituloCfg, 0.12)
        Fuente.dibujar(tituloCfg, (UI.VIRTUAL_ANCHO / 2) - (wCfg / 2), 70, 0.12)

        UI.dibujarSlider(UI.sliderMusica, Audio.volumenMusica, string.upper(UI.getTexto("musica")), Fuente)
        UI.dibujarSlider(UI.sliderFX, Audio.volumenFX, string.upper(UI.getTexto("efectos")), Fuente)
        UI.dibujarSwitch(Fuente)
        UI.dibujarSwitchSaltarAnimaciones(Fuente)
        UI.dibujarSwitchMostrarDatos(Fuente) 
        UI.dibujarSwitchMostrarLogos(Fuente) 
        UI.dibujarSelectorIdioma(Fuente)

        UI.dibujarPanelReyBicho(Fuente)
        UI.dibujarDialogoReyBicho(Fuente)
    end

    if alfaTransicion > 0 then
        love.graphics.setColor(0, 0, 0, alfaTransicion)
        love.graphics.rectangle("fill", 0, 0, UI.VIRTUAL_ANCHO, UI.VIRTUAL_ALTO)
    end
    
    love.graphics.pop()
end
