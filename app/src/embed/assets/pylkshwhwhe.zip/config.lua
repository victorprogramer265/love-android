-- conf.lua
function love.conf(t)
    t.identity = "MiJuegoVertical"
    t.title = "Mi Juego Vertical"
    
    -- Al definir un alto mayor que el ancho, LÖVE forzará a Android a cambiar el modo de pantalla a vertical
    t.window.width = 360
    t.window.height = 640
    t.window.resizable = true
    
    t.modules.touch = true
    t.modules.keyboard = false
end
