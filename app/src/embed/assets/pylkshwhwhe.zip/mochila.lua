-- mochila.lua
local Mochila = {}

Mochila.abierta = false

Mochila.panel = { x = 10, y = 80, ancho = 340, alto = 540 }
Mochila.botonCerrar = { x = 308, y = 88, ancho = 32, alto = 32, presionado = false }
Mochila.botonHUD = { x = 295, y = 15, ancho = 50, alto = 50, presionado = false }

Mochila.imgMochila = nil
Mochila.quadCerrada = nil
Mochila.quadAbierta = nil

Mochila.scroll = 0
Mochila.arrastrandoScroll = false
Mochila.ultimoY = 0
Mochila.maxScroll = 0

function Mochila.cargarAssets()
    if love.filesystem.getInfo and love.filesystem.getInfo("assets/mochila.png") then
        Mochila.imgMochila = love.graphics.newImage("assets/mochila.png")
        Mochila.imgMochila:setFilter("nearest", "nearest")
        
        local mW = Mochila.imgMochila:getWidth()
        local mH = Mochila.imgMochila:getHeight()
        local mitadW = mW / 2

        Mochila.quadCerrada = love.graphics.newQuad(0, 0, mitadW, mH, mW, mH)
        Mochila.quadAbierta = love.graphics.newQuad(mitadW, 0, mitadW, mH, mW, mH)
    end
end

function Mochila.toggle()
    Mochila.abierta = not Mochila.abierta
    if not Mochila.abierta then
        Mochila.arrastrandoScroll = false
    end
end

function Mochila.dibujarBotonHUD()
    love.graphics.setColor(1, 1, 1)
    local btn = Mochila.botonHUD

    if Mochila.imgMochila and Mochila.quadCerrada and Mochila.quadAbierta then
        local quadUsar = Mochila.abierta and Mochila.quadAbierta or Mochila.quadCerrada
        local _, _, qW, qH = quadUsar:getViewport()
        
        local escalaX = btn.ancho / qW
        local escalaY = btn.alto / qH
        love.graphics.draw(Mochila.imgMochila, quadUsar, btn.x, btn.y, 0, escalaX, escalaY)
    else
        if btn.presionado then
            love.graphics.setColor(0.15, 0.45, 0.65)
        else
            love.graphics.setColor(0.2, 0.6, 0.8)
        end
        love.graphics.rectangle("fill", btn.x, btn.y, btn.ancho, btn.alto, 8, 8)
    end
end

function Mochila.mousepressed(vx, vy, button, UI, Personajes, Audio)
    if button ~= 1 or not Mochila.abierta then return false end

    if Personajes and Personajes.instancias then
        for _, p in ipairs(Personajes.instancias) do
            if (p.ubicacion == "mochila" or not p.ubicacion) and p.btnColocar then
                if UI.puntoEnBoton(vx, vy, p.btnColocar) then
                    if Personajes.colocarEnMesa(p, UI, Audio) then
                        return true
                    end
                end
            end
        end
    end

    if UI.puntoEnBoton(vx, vy, Mochila.panel) then
        Mochila.arrastrandoScroll = true
        Mochila.ultimoY = vy
        return true
    end

    return false
end

function Mochila.mousemoved(vx, vy, dy)
    if Mochila.abierta and Mochila.arrastrandoScroll then
        Mochila.scroll = Mochila.scroll - dy
        if Mochila.scroll < 0 then Mochila.scroll = 0 end
        if Mochila.maxScroll and Mochila.scroll > Mochila.maxScroll then
            Mochila.scroll = Mochila.maxScroll
        end
    end
end

function Mochila.mousereleased(button)
    if button == 1 then
        Mochila.arrastrandoScroll = false
    end
end

function Mochila.wheelmoved(x, y)
    if Mochila.abierta then
        Mochila.scroll = Mochila.scroll - (y * 20)
        if Mochila.scroll < 0 then Mochila.scroll = 0 end
        if Mochila.maxScroll and Mochila.scroll > Mochila.maxScroll then
            Mochila.scroll = Mochila.maxScroll
        end
    end
end

function Mochila.dibujar(Fuente, UI, Personajes)
    if not Mochila.abierta then return end

    local p = Mochila.panel

    love.graphics.setColor(0.10, 0.12, 0.18, 1.0)
    love.graphics.rectangle("fill", p.x, p.y, p.ancho, p.alto, 14, 14)

    love.graphics.setColor(0.3, 0.4, 0.6, 1.0)
    love.graphics.setLineWidth(3)
    love.graphics.rectangle("line", p.x, p.y, p.ancho, p.alto, 14, 14)

    love.graphics.setColor(1, 0.6, 0.2, 1.0)
    Fuente.dibujar(string.upper(UI.getTexto("mochila")), p.x + 15, p.y + 15, 0.10)

    love.graphics.setColor(0.85, 0.2, 0.2, 1.0)
    love.graphics.rectangle("fill", Mochila.botonCerrar.x, Mochila.botonCerrar.y, Mochila.botonCerrar.ancho, Mochila.botonCerrar.alto, 8, 8)
    love.graphics.setColor(1, 1, 1, 1.0)
    Fuente.dibujar("X", Mochila.botonCerrar.x + 9, Mochila.botonCerrar.y + 4, 0.09)

    local areaX = p.x + 10
    local areaY = p.y + 60
    local areaAncho = p.ancho - 20
    local areaAlto = p.alto - 70

    local totalItems = 0
    if Personajes and Personajes.instancias then
        for _, inst in ipairs(Personajes.instancias) do
            if inst.ubicacion == "mochila" or inst.ubicacion == nil or inst.ubicacion == "" then
                inst.ubicacion = "mochila"
                totalItems = totalItems + 1
            end
        end
    end

    local altoElemento = 72
    local alturaTotalContenido = totalItems * altoElemento
    Mochila.maxScroll = math.max(0, alturaTotalContenido - areaAlto)

    love.graphics.setScissor(areaX, areaY, areaAncho, areaAlto)

    local itemIndex = 0
    if Personajes and Personajes.instancias then
        for _, inst in ipairs(Personajes.instancias) do
            if inst.ubicacion == "mochila" then
                itemIndex = itemIndex + 1
                local yPos = areaY + (itemIndex - 1) * altoElemento - Mochila.scroll

                if yPos + altoElemento > areaY and yPos < areaY + areaAlto then
                    love.graphics.setColor(0.18, 0.20, 0.28, 1.0)
                    love.graphics.rectangle("fill", areaX, yPos, areaAncho, altoElemento - 8, 8, 8)

                    if inst.textura then
                        love.graphics.setColor(1, 1, 1, 1.0)
                        love.graphics.draw(inst.textura, areaX + 8, yPos + 10, 0, 42 / inst.textura:getWidth(), 42 / inst.textura:getHeight())
                    else
                        love.graphics.setColor(0.2, 0.8, 0.4, 1.0)
                        love.graphics.rectangle("fill", areaX + 8, yPos + 10, 42, 42, 6, 6)
                    end

                    local nivelActual = tostring(inst.nivel or 1)
                    local mpsReal = tostring((inst.mps or 2) * (inst.nivel or 1))
                    local costoActual = tostring(math.floor((inst.cc or 50) * 1.5 * (inst.nivel or 1)))

                    love.graphics.setColor(1, 1, 1, 1.0)
                    Fuente.dibujar(string.upper(inst.nombre or "CRIATURA"), areaX + 56, yPos + 6, 0.045)
                    
                    local escalaTexto = 0.038

                    love.graphics.setColor(0.9, 0.8, 0.2, 1.0)
                    local etiquetaNivel = string.upper(UI.getTexto("nivel")) .. ":"
                    Fuente.dibujar(etiquetaNivel, areaX + 56, yPos + 22, escalaTexto)
                    Fuente.dibujar(nivelActual, areaX + 56 + Fuente.obtenerAncho(etiquetaNivel, escalaTexto) + 4, yPos + 22, escalaTexto)
                    
                    love.graphics.setColor(0.4, 0.9, 0.4, 1.0)
                    local etiquetaMps = string.upper(UI.getTexto("mps")) .. ":"
                    Fuente.dibujar(etiquetaMps, areaX + 56, yPos + 36, escalaTexto)
                    Fuente.dibujar(mpsReal, areaX + 56 + Fuente.obtenerAncho(etiquetaMps, escalaTexto) + 4, yPos + 36, escalaTexto)

                    love.graphics.setColor(1, 0.7, 0.3, 1.0)
                    local etiquetaCc = string.upper(UI.getTexto("costo")) .. ": $"
                    Fuente.dibujar(etiquetaCc, areaX + 56, yPos + 50, escalaTexto)
                    Fuente.dibujar(costoActual, areaX + 56 + Fuente.obtenerAncho(etiquetaCc, escalaTexto) + 4, yPos + 50, escalaTexto)

                    inst.btnColocar = { 
                        x = areaX + 210, 
                        y = yPos + 14, 
                        ancho = 95, 
                        alto = 36 
                    }

                    love.graphics.setColor(0.2, 0.7, 0.3, 1.0)
                    love.graphics.rectangle("fill", inst.btnColocar.x, inst.btnColocar.y, inst.btnColocar.ancho, inst.btnColocar.alto, 6, 6)

                    love.graphics.setColor(1, 1, 1, 1.0)
                    Fuente.dibujar(string.upper(UI.getTexto("colocar")), inst.btnColocar.x + 12, inst.btnColocar.y + 10, 0.042)
                else
                    inst.btnColocar = nil
                end
            end
        end
    end

    if totalItems == 0 then
        love.graphics.setColor(0.6, 0.6, 0.6, 1.0)
        Fuente.dibujar(string.upper(UI.getTexto("mochilaVacia")), areaX + 20, areaY + 20, 0.08)
    end

    love.graphics.setScissor()
end

return Mochila
