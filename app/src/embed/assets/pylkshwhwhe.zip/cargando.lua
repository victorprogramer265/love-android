-- cargando.lua
local Cargando = {}

Cargando.activo = true
Cargando.tiempoTranscurrido = 0
Cargando.duracionLogos = 2.2      -- Tiempo que dura la pantalla de los logos
Cargando.duracionCarga = 2.0      -- Tiempo que dura la pantalla de carga normal
Cargando.duracionTransicion = 0.5 -- Tiempo del fundido (fade) entre fases
Cargando.angulo = 0
Cargando.alfa = 0                 
Cargando.faseInterna = "introLogos" 

Cargando.imgTitulo = nil
Cargando.imgCarga = nil
Cargando.imgLogos = nil

function Cargando.cargarAssets()
    if love.filesystem.getInfo("assets/titulo.png") then
        Cargando.imgTitulo = love.graphics.newImage("assets/titulo.png")
        Cargando.imgTitulo:setFilter("nearest", "nearest")
    end
    
    if love.filesystem.getInfo("assets/carga.png") then
        Cargando.imgCarga = love.graphics.newImage("assets/carga.png")
        Cargando.imgCarga:setFilter("nearest", "nearest")
    end

    if love.filesystem.getInfo("assets/Logos.jpg") then
        Cargando.imgLogos = love.graphics.newImage("assets/Logos.jpg")
        Cargando.imgLogos:setFilter("nearest", "nearest")
    end
end

function Cargando.reiniciar()
    Cargando.activo = true
    Cargando.tiempoTranscurrido = 0
    Cargando.angulo = 0
    Cargando.alfa = 0
    Cargando.faseInterna = "introLogos"
end

function Cargando.update(dt, UI)
    -- Si el usuario desactivó la pantalla de logos en configuración, saltamos directo
    if UI and UI.mostrarLogos == false then
        Cargando.activo = false
        return
    end

    if not Cargando.activo then return end
    
    Cargando.tiempoTranscurrido = Cargando.tiempoTranscurrido + dt
    Cargando.angulo = Cargando.angulo + (math.pi * 2 * dt) * 2.0

    if Cargando.faseInterna == "introLogos" then
        Cargando.alfa = math.min(1, Cargando.tiempoTranscurrido / Cargando.duracionTransicion)
        if Cargando.tiempoTranscurrido >= Cargando.duracionTransicion then
            Cargando.faseInterna = "logos"
            Cargando.tiempoTranscurrido = 0
            Cargando.alfa = 1
        end

    elseif Cargando.faseInterna == "logos" then
        if Cargando.tiempoTranscurrido >= Cargando.duracionLogos then
            Cargando.faseInterna = "fadeLogos"
            Cargando.tiempoTranscurrido = 0
        end

    elseif Cargando.faseInterna == "fadeLogos" then
        Cargando.alfa = 1 - (Cargando.tiempoTranscurrido / Cargando.duracionTransicion)
        if Cargando.tiempoTranscurrido >= Cargando.duracionTransicion then
            Cargando.faseInterna = "introCarga"
            Cargando.tiempoTranscurrido = 0
            Cargando.alfa = 0
        end

    elseif Cargando.faseInterna == "introCarga" then
        Cargando.alfa = math.min(1, Cargando.tiempoTranscurrido / Cargando.duracionTransicion)
        if Cargando.tiempoTranscurrido >= Cargando.duracionTransicion then
            Cargando.faseInterna = "carga"
            Cargando.tiempoTranscurrido = 0
            Cargando.alfa = 1
        end

    elseif Cargando.faseInterna == "carga" then
        if Cargando.tiempoTranscurrido >= Cargando.duracionCarga then
            Cargando.activo = false
        end
    end
end

function Cargando.dibujar(UI)
    if not Cargando.activo then return end
    
    love.graphics.clear(0, 0, 0, 1)

    local centroX = UI.VIRTUAL_ANCHO / 2
    local centroY = UI.VIRTUAL_ALTO / 2

    -- FASE 1: Logos
    if Cargando.faseInterna == "introLogos" or Cargando.faseInterna == "logos" or Cargando.faseInterna == "fadeLogos" then
        if Cargando.imgLogos then
            local wLogos = Cargando.imgLogos:getWidth()
            local hLogos = Cargando.imgLogos:getHeight()
            local escalaLogos = 290 / math.max(wLogos, hLogos)
            
            love.graphics.setColor(1, 1, 1, Cargando.alfa)
            love.graphics.draw(
                Cargando.imgLogos,
                centroX - ((wLogos * escalaLogos) / 2),
                centroY - ((hLogos * escalaLogos) / 2),
                0,
                escalaLogos,
                escalaLogos
            )
        end
    
    -- FASE 2: Título y Carga Giratoria
    elseif Cargando.faseInterna == "introCarga" or Cargando.faseInterna == "carga" then
        if Cargando.imgTitulo then
            local imgAncho = Cargando.imgTitulo:getWidth()
            local escala = 240 / imgAncho
            love.graphics.setColor(1, 1, 1, Cargando.alfa)
            love.graphics.draw(
                Cargando.imgTitulo, 
                centroX - ((imgAncho * escala) / 2), 
                150, 
                0, 
                escala, 
                escala
            )
        end

        if Cargando.imgCarga then
            local w = Cargando.imgCarga:getWidth()
            local h = Cargando.imgCarga:getHeight()
            local escalaCarga = 50 / math.max(w, h)
            
            love.graphics.setColor(1, 1, 1, Cargando.alfa)
            love.graphics.draw(
                Cargando.imgCarga, 
                centroX, 
                420, 
                Cargando.angulo, 
                escalaCarga, 
                escalaCarga, 
                w / 2, 
                h / 2
            )
        end
    end
    
    love.graphics.setColor(1, 1, 1, 1)
end

return Cargando
