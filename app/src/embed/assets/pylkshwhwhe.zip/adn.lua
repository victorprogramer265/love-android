-- adn.lua
local Adn = {}

Adn.slot = { x = 220, y = 430, ancho = 50, alto = 50, contenido = nil }
Adn.botonDar = { x = 200, y = 490, ancho = 90, alto = 35 }

Adn.puntosAdn = 0
Adn.experienciaOculta = 0

function Adn.cargarAssets()
    -- Aquí puedes cargar imágenes si las necesitas en el futuro
end

-- El slot de ADN ya NO genera dinero pasivo
function Adn.update(dt, datosUsuario)
    -- Vacío para evitar cualquier generación de dinero en este slot
end

function Adn.dibujar(Fuente, UI)
    love.graphics.setColor(1, 1, 1, 1)
    local textoAdn = "ADN"
    local wTexto = Fuente.obtenerAncho(textoAdn, 0.08)
    Fuente.dibujar(textoAdn, Adn.slot.x + (Adn.slot.ancho / 2) - (wTexto / 2), Adn.slot.y - 25, 0.08)

    love.graphics.setColor(0.15, 0.15, 0.2, 0.9)
    love.graphics.rectangle("fill", Adn.slot.x, Adn.slot.y, Adn.slot.ancho, Adn.slot.alto, 8, 8)
    
    love.graphics.setColor(0.3, 0.7, 0.9, 1.0)
    love.graphics.setLineWidth(2)
    love.graphics.rectangle("line", Adn.slot.x, Adn.slot.y, Adn.slot.ancho, Adn.slot.alto, 8, 8)

    if Adn.slot.contenido then
        local p = Adn.slot.contenido
        p.x = Adn.slot.x + (Adn.slot.ancho - p.ancho) / 2
        p.y = Adn.slot.y + (Adn.slot.alto - p.alto) / 2
        if p.dibujarSprite then
            p.dibujarSprite(p)
        elseif p.textura then
            love.graphics.setColor(1, 1, 1, 1.0)
            love.graphics.draw(p.textura, p.x, p.y, 0, p.ancho / p.textura:getWidth(), p.alto / p.textura:getHeight())
        else
            love.graphics.setColor(0.2, 0.8, 0.4, 1.0)
            love.graphics.rectangle("fill", p.x, p.y, p.ancho, p.alto, 6, 6)
        end
    end

    local btn = Adn.botonDar
    love.graphics.setColor(0.2, 0.5, 0.8, 1.0)
    love.graphics.rectangle("fill", btn.x, btn.y, btn.ancho, btn.alto, 6, 6)
    
    love.graphics.setColor(1, 1, 1, 1.0)
    love.graphics.setLineWidth(1.5)
    love.graphics.rectangle("line", btn.x, btn.y, btn.ancho, btn.alto, 6, 6)

    local costoTexto = "$0"
    if Adn.slot.contenido then
        local p = Adn.slot.contenido
        p.nivel = p.nivel or 1
        
        -- Costo: 50% más caro que la base, incrementando según el nivel actual
        local costoBase = p.cc or 50
        local costoTotal = math.floor(costoBase * 1.5 * p.nivel)
        costoTexto = "$" .. costoTotal
    end

    local txtBoton = (UI and UI.idioma == "en") and ("DNA " .. costoTexto) or ("ADN " .. costoTexto)
    local wBtn = Fuente.obtenerAncho(txtBoton, 0.05)
    Fuente.dibujar(txtBoton, btn.x + (btn.ancho / 2) - (wBtn / 2), btn.y + 8, 0.05)
end

function Adn.verificarDrop(vx, vy, personajeArrastrado, UI)
    if vx >= Adn.slot.x and vx <= Adn.slot.x + Adn.slot.ancho and
       vy >= Adn.slot.y and vy <= Adn.slot.y + Adn.slot.alto then
        
        if Adn.slot.contenido then return false end

        if personajeArrastrado.ubicacion == "mesa" and personajeArrastrado.slotId and UI.slots and UI.slots[personajeArrastrado.slotId] then
            UI.slots[personajeArrastrado.slotId].contenido = nil
        end

        Adn.slot.contenido = personajeArrastrado
        personajeArrastrado.ubicacion = "adn"
        personajeArrastrado.slotId = nil
        
        return true
    end
    return false
end

function Adn.clicBotonDar(vx, vy, datosUsuario, Audio)
    if vx >= Adn.botonDar.x and vx <= Adn.botonDar.x + Adn.botonDar.ancho and
       vy >= Adn.botonDar.y and vy <= Adn.botonDar.y + Adn.botonDar.alto then
        
        if Audio and Audio.reproducirClick then Audio.reproducirClick() end

        if Adn.slot.contenido then
            local p = Adn.slot.contenido
            p.nivel = p.nivel or 1
            
            local costoBase = p.cc or 50
            local costoTotal = math.floor(costoBase * 1.5 * p.nivel)

            if (datosUsuario.monedas or 0) >= costoTotal then
                datosUsuario.monedas = datosUsuario.monedas - costoTotal
                
                Adn.puntosAdn = Adn.puntosAdn + 1
                
                if Adn.puntosAdn >= 5 then
                    Adn.experienciaOculta = Adn.experienciaOculta + 1
                    Adn.puntosAdn = Adn.puntosAdn - 5
                end

                p.nivel = p.nivel + 1
            end
        end
        return true
    end
    return false
end

return Adn
