-- ============================================================================
-- [PUNTO 1: CONFIGURACIÓN INICIAL Y DECLARACIÓN DE MÓDULOS]
-- Declaración de la tabla principal y carga de dependencias necesarias.
-- ============================================================================
local Personajes = {}
local Vender = require("vender")
local Adn = require("adn")


-- ============================================================================
-- [PUNTO 2: CATÁLOGO BASE DE PERSONAJES (BASE DE DATOS)]
-- Lista con todas las plantillas de personajes, atributos (cc, mps, textura, etc.)
-- ============================================================================
Personajes.lista = {
    {
        id = 1,
        nombre = "BIO-MUTANTE VERDE",
        texturaPath = "assets/personajes/mutante_verde.png",
        cc = 50,
        mps = 2,
        descripcion = "UNA CRIATURA BÁSICA GENERADA EN EL LABORATORIO. PRODUCCIÓN BAJA PERO ECONÓMICA."
    },
    {
        id = 8,
        nombre = "leon bacteriano",
        texturaPath = "assets/personajes/leon.png",
        cc = 200,
        mps = 20,
        descripcion = "N/A"
    },
    {
        id = 2,
        nombre = "ESCARABAJO TOXICO",
        texturaPath = "assets/personajes/escarabajo_toxico.png",
        cc = 150,
        mps = 7,
        descripcion = "SE ALIMENTA DE RESIDUOS RADIACTIVOS. GENERA INGRESOS CONSTANTES."
    },
    {
        id = 3,
        nombre = "ALIEN VISCOSO",
        texturaPath = "assets/personajes/alien_viscoso.png",
        cc = 500,
        mps = 25,
        descripcion = "UN ESPÉCIMEN AVANZADO CON ALTA TASA DE PRODUCCIÓN MONETARIA."
    },
    {
        id = 4,
        nombre = "GELATINA",
        texturaPath = "assets/personajes/jelly_bio.png",
        cc = 1000,
        mps = 55,
        descripcion = "N/A"
    },
    {
        id = 5,
        nombre = "bacteria",
        texturaPath = "assets/personajes/bacteria.png",
        cc = 2000,
        mps = 100,
        descripcion = "N/A"
    },
    {
        id = 6,
        nombre = "perro raro",
        texturaPath = "assets/personajes/perroraro.png",
        cc = 3000,
        mps = 158,
        descripcion = "N/A"
    },
    {
        id = 7,
        nombre = "serpiente alienigena",
        texturaPath = "assets/personajes/viper.png",
        cc = 4000,
        mps = 200,
        descripcion = "N/A"
    },
    
}


-- ============================================================================
-- [PUNTO 3: VARIABLES Y ESTADOS GLOBALES DE PERSONAJES]
-- Control de paneles, la tienda, drag & drop, tiempo de presión e instancias vivas.
-- ============================================================================
Personajes.tiendaAbierta = false
Personajes.panelTienda = { x = 20, y = 100, ancho = 320, alto = 500 }
Personajes.botonCerrarTienda = { x = 290, y = 112, ancho = 32, alto = 32 }

Personajes.scrollY = 0
Personajes.maxScroll = 0
Personajes.arrastrandoScroll = false
Personajes.ultimoY = 0

Personajes.instancias = {}
Personajes.arrastrando = nil
Personajes.offsetX = 0
Personajes.offsetY = 0
Personajes.tiempoPresionado = 0
Personajes.objetoPresionado = nil
Personajes.mostrarInfo = nil
local TIEMPO_CLICK_LARGO = 0.5


-- ============================================================================
-- [PUNTO 4: CARGA DE ASSETS Y TEXTURAS VISUALES]
-- Carga e inicialización de imágenes de personajes en el sistema de archivos LÖVE.
-- ============================================================================
function Personajes.cargarAssets()
    for _, p in ipairs(Personajes.lista) do
        if love.filesystem.getInfo and love.filesystem.getInfo(p.texturaPath) then
            p.textura = love.graphics.newImage(p.texturaPath)
            p.textura:setFilter("nearest", "nearest")
        else
            p.textura = nil
        end
    end
end


-- ============================================================================
-- [PUNTO 5: CREACIÓN E INSTANCIACIÓN DE PERSONAJES]
-- Función encargada de instanciar un personaje en el laboratorio/mochila/mesa.
-- ============================================================================
function Personajes.crearInstancia(idBase, x, y, ubicacion)
    local base = Personajes.lista[idBase]
    if not base then return nil end

    local nuevaInstancia = {
        idBase = base.id,
        nombre = string.upper(base.nombre),
        textura = base.textura,
        cc = base.cc,
        mps = base.mps,
        nivel = 1,
        descripcion = string.upper(base.descripcion),
        x = x or 0,
        y = y or 0,
        ancho = 40,
        alto = 40,
        ubicacion = ubicacion or "mochila",
        slotId = nil,
        btnColocar = nil
    }

    table.insert(Personajes.instancias, nuevaInstancia)
    return nuevaInstancia
end

function Personajes.puntoEnPersonaje(vx, vy, p)
    return vx >= p.x and vx <= (p.x + p.ancho) and vy >= p.y and vy <= (p.y + p.alto)
end


-- ============================================================================
-- [PUNTO 6: SISTEMA DE GUARDADO Y CARGA DE DATOS SEPARADO POR MUNDO]
-- ============================================================================
function Personajes.guardarDatosPorMundo(UI, datosUsuario)
    datosUsuario.personajesMundo1 = datosUsuario.personajesMundo1 or {}
    datosUsuario.personajesMundo2 = datosUsuario.personajesMundo2 or {}

    local tablaMundoActual = {}

    local slotsActivos = (UI.mundoActual == 2) and UI.slotsMundo2 or UI.slotsMundo1
    if slotsActivos then
        for _, slot in ipairs(slotsActivos) do
            if slot.contenido then
                table.insert(tablaMundoActual, {
                    idBase = slot.contenido.idBase,
                    nivel = slot.contenido.nivel or 1,
                    ubicacion = "mesa",
                    slotId = slot.id,
                    x = slot.contenido.x or 0,
                    y = slot.contenido.y or 0
                })
            end
        end
    end

    for _, p in ipairs(Personajes.instancias) do
        if p.ubicacion == "mochila" then
            table.insert(tablaMundoActual, {
                idBase = p.idBase,
                nivel = p.nivel or 1,
                ubicacion = "mochila",
                slotId = nil,
                x = 0,
                y = 0
            })
        end
    end

    if UI.mundoActual == 2 then
        datosUsuario.personajesMundo2 = tablaMundoActual
    else
        datosUsuario.personajesMundo1 = tablaMundoActual
    end
end

function Personajes.guardarDatos()
    local tablaGuardado = {}
    for _, p in ipairs(Personajes.instancias) do
        table.insert(tablaGuardado, {
            idBase = p.idBase,
            nivel = p.nivel or 1,
            ubicacion = p.ubicacion or "mochila",
            slotId = p.slotId,
            x = p.x or 0,
            y = p.y or 0
        })
    end
    return tablaGuardado
end

function Personajes.cargarDatos(tablaCargada, UI)
    Personajes.instancias = {}

    if UI and UI.slotsMundo1 then for _, s in ipairs(UI.slotsMundo1) do s.contenido = nil end end
    if UI and UI.slotsMundo2 then for _, s in ipairs(UI.slotsMundo2) do s.contenido = nil end end
    if UI and UI.slots then for _, s in ipairs(UI.slots) do s.contenido = nil end end
    
    if Adn and Adn.slot then
        Adn.slot.contenido = nil
    end

    if not tablaCargada or type(tablaCargada) ~= "table" then return end

    for _, datosP in ipairs(tablaCargada) do
        local inst = Personajes.crearInstancia(datosP.idBase, datosP.x, datosP.y, datosP.ubicacion)
        if inst then
            inst.nivel = datosP.nivel or 1
            inst.slotId = datosP.slotId
            if UI and datosP.ubicacion == "mesa" and datosP.slotId and UI.slots and UI.slots[datosP.slotId] then
                UI.slots[datosP.slotId].contenido = inst
                inst.x = UI.slots[datosP.slotId].x + (UI.slots[datosP.slotId].ancho - inst.ancho) / 2
                inst.y = UI.slots[datosP.slotId].y + (UI.slots[datosP.slotId].alto - inst.alto) / 2
            elseif datosP.ubicacion == "adn" and Adn and Adn.slot then
                Adn.slot.contenido = inst
                inst.x = Adn.slot.x + (Adn.slot.ancho - inst.ancho) / 2
                inst.y = Adn.slot.y + (Adn.slot.alto - inst.alto) / 2
            end
        end
    end
end

function Personajes.cargarDatosPorMundo(UI, datosUsuario)
    Personajes.instancias = {}
    if UI and UI.slotsMundo1 then for _, s in ipairs(UI.slotsMundo1) do s.contenido = nil end end
    if UI and UI.slotsMundo2 then for _, s in ipairs(UI.slotsMundo2) do s.contenido = nil end end

    local listaMundo = (UI.mundoActual == 2) and (datosUsuario.personajesMundo2 or {}) or (datosUsuario.personajesMundo1 or {})

    for _, datosP in ipairs(listaMundo) do
        local inst = Personajes.crearInstancia(datosP.idBase, datosP.x, datosP.y, datosP.ubicacion)
        if inst then
            inst.nivel = datosP.nivel or 1
            inst.slotId = datosP.slotId
            if datosP.ubicacion == "mesa" and UI and datosP.slotId and UI.slots and UI.slots[datosP.slotId] then
                UI.slots[datosP.slotId].contenido = inst
                inst.x = UI.slots[datosP.slotId].x + (UI.slots[datosP.slotId].ancho - inst.ancho) / 2
                inst.y = UI.slots[datosP.slotId].y + (UI.slots[datosP.slotId].alto - inst.alto) / 2
            end
        end
    end
end

function Personajes.calcularMPSMundo1(datosUsuario)
    local mpsTotal = 0
    local lista = datosUsuario.personajesMundo1 or {}
    for _, p in ipairs(lista) do
        if p.ubicacion == "mesa" then
            local base = Personajes.lista[p.idBase]
            if base then
                mpsTotal = mpsTotal + ((base.mps or 2) * (p.nivel or 1))
            end
        end
    end
    return mpsTotal
end

function Personajes.calcularMPSMundo2(datosUsuario)
    local mpsTotal = 0
    local lista = datosUsuario.personajesMundo2 or {}
    for _, p in ipairs(lista) do
        if p.ubicacion == "mesa" then
            local base = Personajes.lista[p.idBase]
            if base then
                mpsTotal = mpsTotal + ((base.mps or 2) * (p.nivel or 1))
            end
        end
    end
    return mpsTotal
end


-- ============================================================================
-- [PUNTO 7: COMPRA Y COLOCACIÓN EN MESA]
-- ============================================================================
function Personajes.comprar(idBase, datosUsuario, UI, Audio)
    local base = Personajes.lista[idBase]
    if not base then return false end

    if (datosUsuario.monedas or 0) < base.cc then
        return false
    end

    datosUsuario.monedas = datosUsuario.monedas - base.cc
    Personajes.crearInstancia(idBase, 0, 0, "mochila")

    if Audio then Audio.reproducirClick() end
    return true
end

function Personajes.colocarEnMesa(p, UI, Audio)
    if not UI or not UI.slots then return false end

    for _, slot in ipairs(UI.slots) do
        if slot.contenido == nil then
            p.ubicacion = "mesa"
            p.slotId = slot.id
            slot.contenido = p
            p.x = slot.x + (slot.ancho - p.ancho) / 2
            p.y = slot.y + (slot.alto - p.alto) / 2
            if Audio then Audio.reproducirClick() end
            return true
        end
    end
    return false
end


-- ============================================================================
-- [PUNTO 8: BUCLE PRINCIPAL DE ACTUALIZACIÓN (UPDATE) Y MPS CRUZADO]
-- ============================================================================
function Personajes.wheelmoved(x, y)
    if Personajes.tiendaAbierta then
        Personajes.scrollY = Personajes.scrollY - (y * 30)
        Personajes.scrollY = math.max(0, math.min(Personajes.scrollY, Personajes.maxScroll))
    end
end

function Personajes.update(dt, UI, datosUsuario)
    local mpsMesaActual = 0

    if UI and UI.slots then
        for _, slot in ipairs(UI.slots) do
            if slot.contenido and slot.contenido.ubicacion == "mesa" then
                local p = slot.contenido
                local nivelActual = p.nivel or 1
                local mpsReal = (p.mps or 2) * nivelActual
                mpsMesaActual = mpsMesaActual + mpsReal
            end
        end
    end

    local mpsTotalMundo = 0

    if UI.mundoActual == 1 then
        -- En el Mundo 1: Producen las de la mesa del M1 + el pasivo del Mundo 2 en segundo plano
        local mpsPasivoM2 = Personajes.calcularMPSMundo2(datosUsuario)
        mpsTotalMundo = mpsMesaActual + mpsPasivoM2
    else
        -- En el Mundo 2: Producen las de la mesa del M2 + el pasivo del Mundo 1 en segundo plano
        local mpsPasivoM1 = Personajes.calcularMPSMundo1(datosUsuario)
        mpsTotalMundo = mpsMesaActual + mpsPasivoM1
    end

    datosUsuario.acumuladorMPS = mpsTotalMundo
    datosUsuario.monedas = (datosUsuario.monedas or 0) + (mpsTotalMundo * dt)

    if Personajes.arrastrando then
        local x, y = love.mouse.getPosition()
        local vx, vy = UI.transformarCoordenadas(x, y)
        Personajes.arrastrando.x = vx - Personajes.offsetX
        Personajes.arrastrando.y = vy - Personajes.offsetY
    end

    if love.mouse.isDown(1) then
        local x, y = love.mouse.getPosition()
        local vx, vy = UI.transformarCoordenadas(x, y)
        if Personajes.tiendaAbierta and Personajes.arrastrandoScroll then
            local dy = vy - Personajes.ultimoY
            Personajes.scrollY = Personajes.scrollY - dy
            Personajes.scrollY = math.max(0, math.min(Personajes.scrollY, Personajes.maxScroll))
            Personajes.ultimoY = vy
        end
    end

    if love.mouse.isDown(1) and Personajes.objetoPresionado and not Personajes.arrastrando then
        Personajes.tiempoPresionado = Personajes.tiempoPresionado + dt
        if Personajes.tiempoPresionado >= TIEMPO_CLICK_LARGO then
            Personajes.mostrarInfo = Personajes.objetoPresionado
            Personajes.objetoPresionado = nil
        end
    end
end


-- ============================================================================
-- [PUNTO 9: EVENTOS DE INTERACCIÓN Y TOUCH/MOUSE]
-- ============================================================================
function Personajes.mousepressed(vx, vy, button, UI, datosUsuario, Audio, Mochila)
    if button ~= 1 then return false end

    if Vender.verificarClickModal(vx, vy, UI, datosUsuario, Personajes, Audio) then
        return true
    end

    if Personajes.mostrarInfo then
        Personajes.mostrarInfo = nil
        return true
    end

    if Personajes.tiendaAbierta then
        if UI.puntoEnBoton(vx, vy, Personajes.botonCerrarTienda) then
            Personajes.tiendaAbierta = false
            if Audio then Audio.reproducirClick() end
            return true
        end

        local p = Personajes.panelTienda
        local margenTop = 55
        local areaX = p.x + 10
        local areaY = p.y + margenTop
        local areaAncho = p.ancho - 20
        local areaAlto = p.alto - margenTop - 15

        if vx >= areaX and vx <= (areaX + areaAncho) and vy >= areaY and vy <= (areaY + areaAlto) then
            Personajes.arrastrandoScroll = true
            Personajes.ultimoY = vy
        end

        local itemY = areaY - Personajes.scrollY
        local alturaItem = 64
        local espacioEntre = 8

        for i, item in ipairs(Personajes.lista) do
            local btnComprar = { x = p.x + p.ancho - 95, y = itemY + 16, ancho = 85, alto = 32 }
            if vx >= btnComprar.x and vx <= (btnComprar.x + btnComprar.ancho) and vy >= btnComprar.y and vy <= (btnComprar.y + btnComprar.alto) then
                Personajes.comprar(i, datosUsuario, UI, Audio)
                return true
            end
            itemY = itemY + alturaItem + espacioEntre
        end

        if UI.puntoEnBoton(vx, vy, p) then
            return true
        end
    end

    if not (Mochila and Mochila.abierta) and not Personajes.tiendaAbierta then
        for _, p in ipairs(Personajes.instancias) do
            local accesible = (p.ubicacion == "mesa" or p.ubicacion == "adn")
            if accesible and Personajes.puntoEnPersonaje(vx, vy, p) then
                Personajes.arrastrando = p
                Personajes.offsetX = vx - p.x
                Personajes.offsetY = vy - p.y
                Personajes.objetoPresionado = p
                Personajes.tiempoPresionado = 0

                if p.ubicacion == "mesa" and p.slotId and UI.slots and UI.slots[p.slotId] then
                    UI.slots[p.slotId].contenido = nil
                    p.slotId = nil
                elseif p.ubicacion == "adn" and Adn and Adn.slot and Adn.slot.contenido == p then
                    Adn.slot.contenido = nil
                end

                p.ubicacion = "suelto"
                if Audio and Audio.reproducirClick then Audio.reproducirClick() end
                return true
            end
        end
    end

    return false
end

function Personajes.mousereleased(vx, vy, button, UI, Mochila)
    if button ~= 1 then return end

    Personajes.arrastrandoScroll = false
    Personajes.objetoPresionado = nil

    if Personajes.arrastrando then
        local p = Personajes.arrastrando
        Personajes.arrastrando = nil

        if Vender.verificarDrop(vx, vy, p, UI) then return end
        if Adn and Adn.verificarDrop(vx, vy, p, UI) then return end

        local sobreMochila = false
        if Mochila then
            if Mochila.botonHUD and UI.puntoEnBoton(vx, vy, Mochila.botonHUD) then
                sobreMochila = true
            elseif Mochila.abierta and Mochila.panel and UI.puntoEnBoton(vx, vy, Mochila.panel) then
                sobreMochila = true
            end
        end

        if sobreMochila then
            if p.slotId and UI.slots and UI.slots[p.slotId] then
                UI.slots[p.slotId].contenido = nil
            end
            p.ubicacion = "mochila"
            p.slotId = nil
            p.x = 0
            p.y = 0
            return
        end

        if UI.slots then
            for _, slot in ipairs(UI.slots) do
                if UI.puntoEnBoton(vx, vy, slot) then
                    if slot.contenido == nil or slot.contenido == p then
                        if p.slotId and UI.slots[p.slotId] then
                            UI.slots[p.slotId].contenido = nil
                        end
                        p.ubicacion = "mesa"
                        p.slotId = slot.id
                        slot.contenido = p
                        p.x = slot.x + (slot.ancho - p.ancho) / 2
                        p.y = slot.y + (slot.alto - p.alto) / 2
                        return
                    end
                end
            end
        end

        if p.ubicacion == "mesa" and p.slotId and UI.slots and UI.slots[p.slotId] then
            local slot = UI.slots[p.slotId]
            p.x = slot.x + (slot.ancho - p.ancho) / 2
            p.y = slot.y + (slot.alto - p.alto) / 2
        elseif p.ubicacion == "adn" and Adn and Adn.slot then
            p.x = Adn.slot.x + (Adn.slot.ancho - p.ancho) / 2
            p.y = Adn.slot.y + (Adn.slot.alto - p.alto) / 2
        else
            local reubicado = false
            if UI.slots then
                for _, slot in ipairs(UI.slots) do
                    if slot.contenido == nil then
                        slot.contenido = p
                        p.ubicacion = "mesa"
                        p.slotId = slot.id
                        p.x = slot.x + (slot.ancho - p.ancho) / 2
                        p.y = slot.y + (slot.alto - p.alto) / 2
                        reubicado = true
                        break
                    end
                end
            end

            if not reubicado then
                p.ubicacion = "mochila"
                p.slotId = nil
            end
        end
    end
end


-- ============================================================================
-- [PUNTO 10: SISTEMA DE RENDERIZADO Y DIBUJO DE SPRITES]
-- ============================================================================
function Personajes.dibujar(UI, Fuente, datosUsuario, Mochila)
    if not (Mochila and Mochila.abierta) and not Personajes.tiendaAbierta then
        for _, p in ipairs(Personajes.instancias) do
            if (p.ubicacion == "mesa" or p.ubicacion == "adn") and p ~= Personajes.arrastrando then
                Personajes.dibujarSprite(p)
                if UI.mostrarDatosEncima then
                    Personajes.dibujarDatosEncima(p, Fuente)
                end
            end
        end
    end

    if Personajes.arrastrando then
        Personajes.dibujarSprite(Personajes.arrastrando)
        if UI.mostrarDatosEncima then
            Personajes.dibujarDatosEncima(Personajes.arrastrando, Fuente)
        end
    end

    if Personajes.tiendaAbierta then
        Personajes.dibujarTienda(Fuente, datosUsuario, UI)
    end

    if Personajes.mostrarInfo and not Personajes.arrastrando then
        Personajes.dibujarModalInfo(Personajes.mostrarInfo, Fuente, UI)
    end

    Vender.dibujarModal(Fuente)
end

function Personajes.dibujarSprite(p)
    if p.textura then
        love.graphics.setColor(1, 1, 1, 1.0)
        local escalaX = p.ancho / p.textura:getWidth()
        local escalaY = p.alto / p.textura:getHeight()
        love.graphics.draw(p.textura, p.x, p.y, 0, escalaX, escalaY)
    else
        love.graphics.setColor(0.2, 0.8, 0.4, 1.0)
        love.graphics.rectangle("fill", p.x, p.y, p.ancho, p.alto, 6, 6)
        love.graphics.setColor(1, 1, 1, 1.0)
        love.graphics.rectangle("line", p.x, p.y, p.ancho, p.alto, 6, 6)
    end
end

function Personajes.dibujarDatosEncima(p, Fuente)
    local nivelActual = tostring(p.nivel or 1)
    local mpsActual = tostring((p.mps or 2) * (p.nivel or 1))
    local costoActual = tostring(math.floor((p.cc or 50) * 1.5 * (p.nivel or 1)))

    local escalaTexto = 0.038
    local anchoMax = 44
    local altoLinea = 12
    local totalAlto = altoLinea * 3 + 4
    
    local posX = p.x + (p.ancho / 2) - (anchoMax / 2)
    local posY = p.y - totalAlto - 4

    love.graphics.setColor(0, 0, 0, 0.85)
    love.graphics.rectangle("fill", posX, posY, anchoMax, totalAlto, 4, 4)

    love.graphics.setColor(1, 1, 1, 1)
    Fuente.dibujar("NIVEL: " .. nivelActual, posX + 2, posY + 2, escalaTexto)
    Fuente.dibujar("MPS: " .. mpsActual, posX + 2, posY + 2 + altoLinea, escalaTexto)
    Fuente.dibujar("CC: $" .. costoActual, posX + 2, posY + 2 + (altoLinea * 2), escalaTexto)
end


-- ============================================================================
-- [PUNTO 11: RENDERING DE TIENDA Y VENTANAS MODALES]
-- ============================================================================
function Personajes.dibujarTienda(Fuente, datosUsuario, UI)
    local p = Personajes.panelTienda

    love.graphics.setColor(0.1, 0.12, 0.18, 1.0)
    love.graphics.rectangle("fill", p.x, p.y, p.ancho, p.alto, 12, 12)
    love.graphics.setColor(0.9, 0.7, 0.2, 1.0)
    love.graphics.setLineWidth(3)
    love.graphics.rectangle("line", p.x, p.y, p.ancho, p.alto, 12, 12)

    love.graphics.setColor(1, 1, 1, 1.0)
    Fuente.dibujar(string.upper(UI.getTexto("tienda")), p.x + 20, p.y + 15, 0.10)

    love.graphics.setColor(0.8, 0.2, 0.2, 1.0)
    love.graphics.rectangle("fill", Personajes.botonCerrarTienda.x, Personajes.botonCerrarTienda.y, 32, 32, 6, 6)
    love.graphics.setColor(1, 1, 1, 1.0)
    Fuente.dibujar("X", Personajes.botonCerrarTienda.x + 9, Personajes.botonCerrarTienda.y + 4, 0.10)

    local margenTop = 55
    local areaX = p.x + 10
    local areaY = p.y + margenTop
    local areaAncho = p.ancho - 20
    local areaAlto = p.alto - margenTop - 15

    local alturaItem = 64
    local espacioEntre = 8
    Personajes.alturaContenido = #Personajes.lista * (alturaItem + espacioEntre)
    Personajes.maxScroll = math.max(0, Personajes.alturaContenido - areaAlto)

    local anchoReal = love.graphics.getWidth()
    local altoReal = love.graphics.getHeight()
    local escalaX = anchoReal / UI.VIRTUAL_ANCHO
    local escalaY = altoReal / UI.VIRTUAL_ALTO

    love.graphics.setScissor(areaX * escalaX, areaY * escalaY, areaAncho * escalaX, areaAlto * escalaY)

    love.graphics.push()
    love.graphics.translate(0, -Personajes.scrollY)

    local itemY = areaY
    for _, item in ipairs(Personajes.lista) do
        love.graphics.setColor(0.18, 0.2, 0.28, 1.0)
        love.graphics.rectangle("fill", areaX, itemY, areaAncho, alturaItem, 8, 8)

        if item.textura then
            love.graphics.setColor(1, 1, 1, 1.0)
            love.graphics.draw(item.textura, areaX + 5, itemY + 12, 0, 40 / item.textura:getWidth(), 40 / item.textura:getHeight())
        else
            love.graphics.setColor(0.2, 0.8, 0.4, 1.0)
            love.graphics.rectangle("fill", areaX + 5, itemY + 12, 40, 40, 6, 6)
        end

        love.graphics.setColor(1, 1, 1, 1.0)
        Fuente.dibujar(string.upper(item.nombre), areaX + 52, itemY + 6, 0.048)

        love.graphics.setColor(0.4, 0.9, 0.4, 1.0)
        Fuente.dibujar("MPS: +" .. tostring(item.mps), areaX + 52, itemY + 24, 0.045)

        love.graphics.setColor(1, 0.8, 0.2, 1.0)
        Fuente.dibujar("CC: $" .. tostring(item.cc), areaX + 52, itemY + 42, 0.045)

        local puedeComprar = (datosUsuario.monedas or 0) >= item.cc
        if puedeComprar then
            love.graphics.setColor(0.2, 0.7, 0.3, 1.0)
        else
            love.graphics.setColor(0.4, 0.4, 0.4, 1.0)
        end
        love.graphics.rectangle("fill", areaX + areaAncho - 85, itemY + 16, 75, 32, 6, 6)

        love.graphics.setColor(1, 1, 1, 1.0)
        Fuente.dibujar(string.upper(UI.getTexto("comprar")), areaX + areaAncho - 80, itemY + 22, 0.04)

        itemY = itemY + alturaItem + espacioEntre
    end

    love.graphics.pop()
    love.graphics.setScissor()
end

function Personajes.dibujarModalInfo(p, Fuente, UI)
    local panel = { x = 40, y = 150, ancho = 280, alto = 320 }

    love.graphics.setColor(0.08, 0.08, 0.12, 1.0)
    love.graphics.rectangle("fill", panel.x, panel.y, panel.ancho, panel.alto, 12, 12)
    love.graphics.setColor(0.2, 0.7, 0.9, 1.0)
    love.graphics.setLineWidth(3)
    love.graphics.rectangle("line", panel.x, panel.y, panel.ancho, panel.alto, 12, 12)

    love.graphics.setColor(0.8, 0.2, 0.2, 1.0)
    love.graphics.rectangle("fill", panel.x + panel.ancho - 35, panel.y + 10, 25, 25, 6, 6)
    love.graphics.setColor(1, 1, 1, 1.0)
    Fuente.dibujar("X", panel.x + panel.ancho - 28, panel.y + 12, 0.08)

    Fuente.dibujar(string.upper(p.nombre), panel.x + 15, panel.y + 20, 0.09)

    local previewX = panel.x + (panel.ancho / 2) - 30
    local previewY = panel.y + 55
    if p.textura then
        local escX = 60 / p.textura:getWidth()
        local escY = 60 / p.textura:getHeight()
        love.graphics.draw(p.textura, previewX, previewY, 0, escX, escY)
    else
        love.graphics.setColor(0.2, 0.8, 0.4, 1.0)
        love.graphics.rectangle("fill", previewX, previewY, 60, 60, 8, 8)
    end

    love.graphics.setColor(1, 1, 1, 1.0)
    local mpsActual = p.mps * (p.nivel or 1)
    Fuente.dibujar("MPS: " .. tostring(mpsActual) .. " /SEG", panel.x + 20, panel.y + 130, 0.08)
    Fuente.dibujar("NIVEL: " .. tostring(p.nivel or 1), panel.x + 150, panel.y + 130, 0.08)
    
    Fuente.dibujar(string.upper(UI.getTexto("costo")) .. ": " .. tostring(p.cc), panel.x + 20, panel.y + 155, 0.08)

    Fuente.dibujar(string.upper(UI.getTexto("detalles")) .. ":", panel.x + 20, panel.y + 190, 0.075)
    love.graphics.setColor(0.8, 0.8, 0.8, 1.0)
    love.graphics.printf(string.upper(p.descripcion), panel.x + 20, panel.y + 215, panel.ancho - 40, "left")
end

return Personajes
